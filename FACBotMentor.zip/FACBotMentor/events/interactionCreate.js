module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      
      if (!command) {
        console.error(`❌ Commande non trouvée: ${interaction.commandName}`);
        return;
      }
      
      try {
        await command.execute(interaction);
      } catch (error) {
        console.error(`Erreur lors de l'exécution de ${interaction.commandName}:`, error);
        const errorMessage = {
          content: '❌ Une erreur est survenue lors de l\'exécution de cette commande!',
          ephemeral: true
        };
        
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(errorMessage);
        } else {
          await interaction.reply(errorMessage);
        }
      }
    } else if (interaction.isButton()) {
      const button = client.buttons.get(interaction.customId);
      
      if (!button) {
        console.error(`❌ Bouton non trouvé: ${interaction.customId}`);
        return;
      }
      
      try {
        await button.execute(interaction);
      } catch (error) {
        console.error(`Erreur lors du clic sur le bouton ${interaction.customId}:`, error);
        await interaction.reply({
          content: '❌ Une erreur est survenue!',
          ephemeral: true
        });
      }
    } else if (interaction.isStringSelectMenu()) {
      let menu = client.selectMenus.get(interaction.customId);
      
      if (!menu) {
        for (const [key, value] of client.selectMenus) {
          if (key instanceof RegExp && key.test(interaction.customId)) {
            menu = value;
            break;
          }
        }
      }
      
      if (!menu) {
        console.error(`❌ Menu déroulant non trouvé: ${interaction.customId}`);
        return;
      }
      
      try {
        await menu.execute(interaction);
      } catch (error) {
        console.error(`Erreur lors de la sélection du menu ${interaction.customId}:`, error);
        await interaction.reply({
          content: '❌ Une erreur est survenue!',
          ephemeral: true
        });
      }
    }
  },
};
