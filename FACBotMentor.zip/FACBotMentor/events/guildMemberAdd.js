const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member) {
    const welcomeChannel = member.guild.channels.cache.find(
      channel => channel.name === 'bienvenue' || channel.name === 'welcome' || channel.name === 'général'
    );
    
    if (!welcomeChannel) return;
    
    const embed = new EmbedBuilder()
      .setColor('#00FF00')
      .setTitle(`🎉 Bienvenue ${member.user.username}!`)
      .setDescription(`Bienvenue sur **${member.guild.name}**!\n\nNous sommes ravis de t'accueillir dans notre communauté d'apprentissage du code!`)
      .addFields(
        { name: '📚 Pour commencer', value: 'Utilise `/tutoriels` pour voir tous les tutoriels disponibles', inline: false },
        { name: '💡 Besoin d\'aide?', value: 'Clique sur le bouton Support ci-dessous pour créer un ticket', inline: false },
        { name: '🚀 Projets pratiques', value: 'Tape `/projets` pour découvrir des projets à réaliser', inline: false }
      )
      .setThumbnail(member.user.displayAvatarURL())
      .setFooter({ text: 'FAC Bot - Apprends, Code, Crée!' })
      .setTimestamp();
    
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('start_learning')
          .setLabel('🎓 Commencer à apprendre')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('create_support_ticket')
          .setLabel('🎫 Support')
          .setStyle(ButtonStyle.Secondary)
      );
    
    try {
      await welcomeChannel.send({
        content: `<@${member.id}>`,
        embeds: [embed],
        components: [row]
      });
    } catch (error) {
      console.error('Erreur lors de l\'envoi du message de bienvenue:', error);
    }
  },
};
