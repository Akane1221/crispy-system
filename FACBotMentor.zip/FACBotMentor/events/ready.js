module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    console.log(`✅ ${client.user.tag} est maintenant en ligne!`);
    console.log(`🤖 FAC Bot est connecté sur ${client.guilds.cache.size} serveur(s)`);
    
    client.user.setActivity('Apprendre à coder ensemble! 📚', { type: 'WATCHING' });
  },
};
