
const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  customId: 'confirm_server_clear',
  async execute(interaction) {
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({
        content: '❌ Tu dois être administrateur pour utiliser cette commande!',
        ephemeral: true
      });
    }

    await interaction.update({
      content: '```ansi\n[2;31m╔════════════════════════════════════╗\n║   💣 DESTRUCTION EN COURS...     ║\n╚════════════════════════════════════╝[0m\n```',
      embeds: [],
      components: []
    });

    const guild = interaction.guild;
    let deletedChannels = 0;
    let deletedRoles = 0;
    let errors = 0;

    try {
      // Supprimer tous les salons
      const channels = guild.channels.cache.filter(channel => {
        return channel.deletable;
      });

      await interaction.editReply('```ansi\n[2;33m🗑️ Suppression des salons... (0/' + channels.size + ')[0m\n```');

      for (const [id, channel] of channels) {
        try {
          await channel.delete('Nettoyage serveur via /clear');
          deletedChannels++;
          
          if (deletedChannels % 5 === 0) {
            await interaction.editReply('```ansi\n[2;33m🗑️ Suppression des salons... (' + deletedChannels + '/' + channels.size + ')[0m\n```');
          }
          
          await new Promise(resolve => setTimeout(resolve, 300));
        } catch (error) {
          console.error(`Erreur suppression salon ${channel.name}:`, error);
          errors++;
        }
      }

      // Supprimer tous les rôles (sauf @everyone et rôles intégrés)
      const roles = guild.roles.cache.filter(role => {
        return role.editable && 
               role.id !== guild.id && 
               !role.managed &&
               role.name !== '@everyone';
      });

      await interaction.editReply('```ansi\n[2;35m🗑️ Suppression des rôles... (0/' + roles.size + ')[0m\n```');

      for (const [id, role] of roles) {
        try {
          await role.delete('Nettoyage serveur via /clear');
          deletedRoles++;
          
          if (deletedRoles % 3 === 0) {
            await interaction.editReply('```ansi\n[2;35m🗑️ Suppression des rôles... (' + deletedRoles + '/' + roles.size + ')[0m\n```');
          }
          
          await new Promise(resolve => setTimeout(resolve, 500));
        } catch (error) {
          console.error(`Erreur suppression rôle ${role.name}:`, error);
          errors++;
        }
      }

      // Message de succès
      const successEmbed = new EmbedBuilder()
        .setColor('#00FF00')
        .setTitle('```ansi\n[2;32m╔═══════════════════════════════════════════╗\n║      ✅  SERVEUR NETTOYÉ  ✅            ║\n╚═══════════════════════════════════════════╝[0m\n```')
        .setDescription('```ansi\n[2;32m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀[0m\n```\n\n## 🗑️ **SUPPRESSION TERMINÉE**\n\n```ansi\n[2;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n[1;37m            STATISTIQUES                    [0m\n[2;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n```\n\n### 📊 **RÉSULTATS:**\n\n✅ **' + deletedChannels + ' salons** supprimés\n✅ **' + deletedRoles + ' rôles** supprimés\n' + (errors > 0 ? '⚠️ **' + errors + ' erreurs** rencontrées\n' : '') + '\n```ansi\n[2;32m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀[0m\n```\n\n### 🚀 **PROCHAINES ÉTAPES:**\n\n💡 Utilise `/setup` pour recréer le serveur\n💡 Ou configure manuellement ton serveur\n\n```ansi\n[2;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n[1;37m      Le serveur est maintenant vide!       [0m\n[2;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n```')
        .setFooter({ text: '🗑️ Nettoyage effectué par FAC Bot' })
        .setTimestamp();

      await interaction.editReply({ 
        content: null,
        embeds: [successEmbed] 
      });

    } catch (error) {
      console.error('Erreur lors du nettoyage:', error);
      
      const errorEmbed = new EmbedBuilder()
        .setColor('#FF0000')
        .setTitle('❌ Erreur lors du nettoyage')
        .setDescription('**Erreur:** ' + error.message + '\n\n**Supprimé:**\n• ' + deletedChannels + ' salons\n• ' + deletedRoles + ' rôles')
        .setFooter({ text: 'Certains éléments ont pu être supprimés malgré l\'erreur' });

      await interaction.editReply({ 
        content: null,
        embeds: [errorEmbed] 
      });
    }
  },
};
