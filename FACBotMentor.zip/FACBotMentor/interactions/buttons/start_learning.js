const { EmbedBuilder } = require('discord.js');

module.exports = {
  id: 'start_learning',
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor('#2ecc71')
      .setTitle('🎓 Commence ton aventure d\'apprentissage!')
      .setDescription('Voici comment démarrer avec FAC Bot:\n')
      .addFields(
        {
          name: '1️⃣ Explore les tutoriels',
          value: 'Utilise `/tutoriels` pour voir tous les cours disponibles par niveau',
          inline: false
        },
        {
          name: '2️⃣ Choisis un langage',
          value: 'JavaScript, Python, HTML/CSS - commence par celui qui t\'intéresse!',
          inline: false
        },
        {
          name: '3️⃣ Pratique avec des projets',
          value: 'Tape `/projets` pour découvrir des projets concrets à réaliser',
          inline: false
        },
        {
          name: '4️⃣ Demande de l\'aide',
          value: 'Utilise `/support` si tu es bloqué - la communauté est là pour t\'aider!',
          inline: false
        },
        {
          name: '💡 Conseil',
          value: 'La meilleure façon d\'apprendre est de **pratiquer régulièrement**. Même 30 minutes par jour font une grande différence!',
          inline: false
        }
      )
      .setFooter({ text: 'Tu as toutes les clés pour réussir!' })
      .setTimestamp();

    await interaction.reply({
      embeds: [embed],
      ephemeral: true
    });
  },
};
