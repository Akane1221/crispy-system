const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  id: 'close_ticket',
  async execute(interaction) {
    const channel = interaction.channel;

    if (!channel.name.startsWith('ticket-')) {
      await interaction.reply({
        content: '❌ Cette commande ne peut être utilisée que dans un ticket!',
        ephemeral: true
      });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor('#e74c3c')
      .setTitle('🔒 Fermeture du Ticket')
      .setDescription('Ce ticket va être fermé dans 5 secondes...\n\nMerci d\'avoir utilisé le support!')
      .setFooter({ text: 'FAC Bot Support' })
      .setTimestamp();

    await interaction.reply({
      embeds: [embed]
    });

    setTimeout(async () => {
      try {
        await channel.delete();
      } catch (error) {
        console.error('Erreur suppression ticket:', error);
      }
    }, 5000);
  },
};
