const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');

module.exports = {
  id: 'back_to_levels',
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor('#3498db')
      .setTitle('📚 Tutoriels de Programmation - FAC Bot')
      .setDescription('Choisis ton niveau et le langage que tu veux apprendre!\n\n**Niveaux disponibles:**\n🟢 Débutant - Pour ceux qui commencent\n🟡 Intermédiaire - Pour progresser\n🔴 Avancé - Pour se perfectionner')
      .addFields(
        { name: '💻 JavaScript', value: 'Le langage du web et du développement moderne', inline: true },
        { name: '🐍 Python', value: 'Polyvalent et facile à apprendre', inline: true },
        { name: '🎨 HTML/CSS', value: 'Crée des sites web magnifiques', inline: true }
      )
      .setFooter({ text: 'Sélectionne un niveau ci-dessous pour commencer' })
      .setTimestamp();

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('tutorial_level')
      .setPlaceholder('🎯 Sélectionne ton niveau')
      .addOptions([
        {
          label: 'Débutant',
          description: 'Commence ton apprentissage du code',
          value: 'beginner',
          emoji: '🟢'
        },
        {
          label: 'Intermédiaire',
          description: 'Améliore tes compétences',
          value: 'intermediate',
          emoji: '🟡'
        },
        {
          label: 'Avancé',
          description: 'Maîtrise des concepts avancés',
          value: 'advanced',
          emoji: '🔴'
        }
      ]);

    const row = new ActionRowBuilder().addComponents(selectMenu);

    await interaction.update({
      content: null,
      embeds: [embed],
      components: [row]
    });
  },
};
