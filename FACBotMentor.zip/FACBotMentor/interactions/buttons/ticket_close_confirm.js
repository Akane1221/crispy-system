
const { EmbedBuilder } = require('discord.js');

module.exports = {
  id: 'ticket_close_confirm',
  async execute(interaction) {
    const channel = interaction.channel;

    const closingEmbed = new EmbedBuilder()
      .setColor('#FF1744')
      .setTitle('🔒 『 FERMETURE EN COURS 』')
      .setDescription(`\`\`\`ansi\n[2;31m▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰[0m\n[2;37mSYSTÈME EN ARRÊT[0m\n[2;31m▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰[0m\n\`\`\`\n\n╔═══════════════════════╗\n║  **TICKET FERMÉ**  ║\n╚═══════════════════════╝\n\n✅ **Transcript sauvegardé**\n📦 **Archivage en cours...**\n⏱️ **Suppression dans 10 secondes**\n\n━━━━━━━━━━━━━━━━━━━━━\n\n**Merci d'avoir utilisé le support FAC!**\nÀ bientôt pour de nouveaux défis! 🚀`)
      .setFooter({ text: '『 FAC QUANTUM SUPPORT 』• Merci de ta visite' })
      .setTimestamp();

    await interaction.update({
      embeds: [closingEmbed],
      components: []
    });

    setTimeout(async () => {
      try {
        await channel.delete();
      } catch (error) {
        console.error('Erreur suppression ticket:', error);
      }
    }, 10000);
  },
};
