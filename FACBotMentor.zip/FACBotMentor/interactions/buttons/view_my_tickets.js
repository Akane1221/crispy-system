const { EmbedBuilder, ChannelType } = require('discord.js');

function slugifyUsername(username) {
  return username
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-_]/g, '')
    .substring(0, 80);
}

module.exports = {
  id: 'view_my_tickets',
  async execute(interaction) {
    const guild = interaction.guild;
    const member = interaction.member;
    
    const ticketName = `ticket-${slugifyUsername(member.user.username)}`;

    const userTickets = guild.channels.cache.filter(
      channel => channel.name === ticketName && channel.type === ChannelType.GuildText
    );

    if (userTickets.size === 0) {
      await interaction.reply({
        content: '📋 Tu n\'as aucun ticket ouvert actuellement.',
        ephemeral: true
      });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor('#3498db')
      .setTitle('📋 Tes Tickets de Support')
      .setDescription('Voici tes tickets actuellement ouverts:')
      .addFields(
        userTickets.map(ticket => ({
          name: `🎫 ${ticket.name}`,
          value: `<#${ticket.id}>`,
          inline: false
        }))
      )
      .setFooter({ text: `${userTickets.size} ticket(s) ouvert(s)` })
      .setTimestamp();

    await interaction.reply({
      embeds: [embed],
      ephemeral: true
    });
  },
};
