
const { EmbedBuilder } = require('discord.js');

module.exports = {
  id: 'ticket_close_cancel',
  async execute(interaction) {
    const cancelEmbed = new EmbedBuilder()
      .setColor('#00FF88')
      .setTitle('✅ 『 FERMETURE ANNULÉE 』')
      .setDescription(`\`\`\`ansi\n[2;32m▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰[0m\n[2;37mTICKET TOUJOURS ACTIF[0m\n[2;32m▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰[0m\n\`\`\`\n\n╔═══════════════════════╗\n║  **CONTINUER LE SUPPORT**  ║\n╚═══════════════════════╝\n\n🎯 **Le ticket reste ouvert**\n💬 **Continue la discussion**\n\n━━━━━━━━━━━━━━━━━━━━━\n\nN'hésite pas à poser toutes tes questions! 🚀`)
      .setFooter({ text: '『 FAC QUANTUM SUPPORT 』• Ticket actif' })
      .setTimestamp();

    await interaction.update({
      embeds: [cancelEmbed],
      components: []
    });
  },
};
