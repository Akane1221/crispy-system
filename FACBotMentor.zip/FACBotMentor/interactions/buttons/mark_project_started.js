const { EmbedBuilder } = require('discord.js');

module.exports = {
  id: 'mark_project_started',
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor('#2ecc71')
      .setTitle('🚀 Projet Commencé!')
      .setDescription('Félicitations pour avoir commencé ce projet!\n\n**Conseils pour réussir:**\n\n✅ **Planifie d\'abord** - Réfléchis à l\'architecture avant de coder\n✅ **Code par étapes** - Commence par les fonctionnalités de base\n✅ **Teste souvent** - Vérifie que tout fonctionne au fur et à mesure\n✅ **Demande de l\'aide** - N\'hésite pas à utiliser `/support` si tu bloques\n✅ **Partage ton progrès** - Montre tes avancées à la communauté!\n\n💡 **Rappel:** Le code parfait n\'existe pas. L\'important est d\'apprendre et de progresser!')
      .addFields(
        { name: '📝 Prochaines étapes', value: '1. Crée un nouveau projet/dossier\n2. Installe les outils nécessaires\n3. Commence par une fonctionnalité simple\n4. Partage tes questions dans le support!', inline: false }
      )
      .setFooter({ text: 'Bonne chance avec ton projet! 🎉' })
      .setTimestamp();

    await interaction.reply({
      embeds: [embed],
      ephemeral: true
    });
  },
};
