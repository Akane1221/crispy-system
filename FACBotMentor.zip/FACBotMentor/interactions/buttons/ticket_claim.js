
const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  id: 'ticket_claim',
  async execute(interaction) {
    const channel = interaction.channel;
    const claimer = interaction.member;

    if (!channel.name.startsWith('ticket-')) {
      await interaction.reply({
        content: '❌ Cette action est uniquement disponible dans un ticket!',
        ephemeral: true
      });
      return;
    }

    const claimEmbed = new EmbedBuilder()
      .setColor('#00FF88')
      .setTitle('🛡️ 『 TICKET PRIS EN CHARGE 』')
      .setDescription(`\`\`\`ansi\n[2;32m▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰[0m\n[2;37mMENTOR ASSIGNÉ[0m\n[2;32m▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰[0m\n\`\`\`\n\n╔═══════════════════════╗\n║  **SUPPORT ACTIVÉ**  ║\n╚═══════════════════════╝\n\n🎯 **Mentor:** ${claimer}\n⏰ **Pris en charge:** <t:${Math.floor(Date.now() / 1000)}:R>\n\n━━━━━━━━━━━━━━━━━━━━━\n\n**Le mentor va t'aider à résoudre ton problème!**\nSois patient et suis ses instructions. 🚀`)
      .setThumbnail(claimer.user.displayAvatarURL({ dynamic: true }))
      .setFooter({ text: '『 FAC QUANTUM SUPPORT 』• Mentor assigné' })
      .setTimestamp();

    await channel.permissionOverwrites.edit(claimer.id, {
      ViewChannel: true,
      SendMessages: true,
      ReadMessageHistory: true
    });

    await channel.send({ embeds: [claimEmbed] });

    await interaction.reply({
      content: '✅ Tu as pris en charge ce ticket!',
      ephemeral: true
    });
  },
};
