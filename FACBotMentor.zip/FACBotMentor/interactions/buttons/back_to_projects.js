const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const projectsData = require('../../data/projects.json');

module.exports = {
  id: 'back_to_projects',
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor('#e67e22')
      .setTitle('🚀 Projets Pratiques - FAC Bot')
      .setDescription('Mets en pratique ce que tu as appris avec des projets concrets!\n\n**Pourquoi faire des projets?**\n✅ Apprendre en pratiquant\n✅ Construire ton portfolio\n✅ Développer des compétences réelles\n✅ Avoir des réalisations à montrer')
      .addFields(
        { name: '🟢 Débutant', value: `${projectsData.projects.filter(p => p.difficulty === 'Débutant').length} projets`, inline: true },
        { name: '🟡 Intermédiaire', value: `${projectsData.projects.filter(p => p.difficulty === 'Intermédiaire').length} projets`, inline: true },
        { name: '🔴 Avancé', value: `${projectsData.projects.filter(p => p.difficulty === 'Avancé').length} projets`, inline: true }
      )
      .setFooter({ text: 'Sélectionne un projet pour voir les détails' })
      .setTimestamp();

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('project_select')
      .setPlaceholder('🎯 Choisis un projet')
      .addOptions(
        projectsData.projects.map(project => ({
          label: project.title,
          description: `${project.difficulty} - ${project.estimated_time}`,
          value: project.id,
          emoji: project.title.split(' ')[0]
        }))
      );

    const row = new ActionRowBuilder().addComponents(selectMenu);

    await interaction.update({
      content: null,
      embeds: [embed],
      components: [row]
    });
  },
};
