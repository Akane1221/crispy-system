
const { EmbedBuilder } = require('discord.js');

module.exports = {
  customId: 'cancel_server_clear',
  async execute(interaction) {
    const cancelEmbed = new EmbedBuilder()
      .setColor('#00FF00')
      .setTitle('```ansi\n[2;32m╔═══════════════════════════════════════════╗\n║        ✅  OPÉRATION ANNULÉE  ✅        ║\n╚═══════════════════════════════════════════╝[0m\n```')
      .setDescription('```ansi\n[2;32m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀[0m\n```\n\n## 🛡️ **SERVEUR PROTÉGÉ**\n\n> La suppression a été annulée avec succès!\n\n✅ Tous tes salons sont intacts\n✅ Tous tes rôles sont préservés\n✅ Aucune donnée n\'a été perdue\n\n```ansi\n[2;32m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀[0m\n```')
      .setFooter({ text: '🛡️ Bonne décision!' })
      .setTimestamp();

    await interaction.update({
      embeds: [cancelEmbed],
      components: []
    });
  },
};
