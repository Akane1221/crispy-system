
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  id: 'ticket_close',
  async execute(interaction) {
    const channel = interaction.channel;

    if (!channel.name.startsWith('ticket-')) {
      await interaction.reply({
        content: '❌ Cette action est uniquement disponible dans un ticket!',
        ephemeral: true
      });
      return;
    }

    const confirmEmbed = new EmbedBuilder()
      .setColor('#FF6B35')
      .setTitle('⚠️ 『 CONFIRMATION DE FERMETURE 』')
      .setDescription(`\`\`\`ansi\n[2;33m▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰[0m\n[2;37mATTENTION[0m\n[2;33m▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰[0m\n\`\`\`\n\n╔═══════════════════════╗\n║  **FERMER CE TICKET?**  ║\n╚═══════════════════════╝\n\n❓ **Es-tu sûr de vouloir fermer?**\n\n**Ce qui va se passer:**\n✓ Transcript automatique sauvegardé\n✓ Salon supprimé dans 10 secondes\n✓ Historique archivé\n\n━━━━━━━━━━━━━━━━━━━━━\n\n**Si ton problème n'est pas résolu,**\n**annule et continue la discussion!**`)
      .setFooter({ text: '『 FAC QUANTUM SUPPORT 』• Système de fermeture' })
      .setTimestamp();

    const confirmRow = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('ticket_close_confirm')
          .setLabel('Confirmer la fermeture')
          .setEmoji('✅')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('ticket_close_cancel')
          .setLabel('Annuler')
          .setEmoji('❌')
          .setStyle(ButtonStyle.Secondary)
      );

    await interaction.reply({
      embeds: [confirmEmbed],
      components: [confirmRow]
    });
  },
};
