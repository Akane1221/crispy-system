
const { EmbedBuilder, ChannelType, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');

function slugifyUsername(username) {
  return username
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-_]/g, '')
    .substring(0, 80);
}

module.exports = {
  id: 'create_support_ticket',
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const guild = interaction.guild;
    const member = interaction.member;
    
    const ticketName = `ticket-${slugifyUsername(member.user.username)}`;

    const existingTicket = guild.channels.cache.find(
      channel => channel.name === ticketName && channel.type === ChannelType.GuildText
    );

    if (existingTicket) {
      const existingEmbed = new EmbedBuilder()
        .setColor('#FF1744')
        .setTitle('⚠️ 『 TICKET DÉJÀ ACTIF 』')
        .setDescription(`\`\`\`ansi\n[2;31m[2;31m▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰[0m[2;31m[0m\n[2;33mSTATUT: [0m[2;31mACTIF[0m\n[2;31m▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰[0m\n\`\`\`\n╔═══════════════════════╗\n║  **SYSTÈME DE TICKETS**  ║\n╚═══════════════════════╝\n\n🎫 **Ton ticket est déjà ouvert**\n📍 Localisation: <#${existingTicket.id}>\n\n⚡ **Actions disponibles:**\n└ Rends-toi dans ton ticket actif\n└ Ferme-le avant d'en créer un nouveau`)
        .setThumbnail('https://cdn.discordapp.com/attachments/1234567890/warning.gif')
        .setFooter({ text: '『 FAC QUANTUM SUPPORT 』• Système V3.0', iconURL: guild.iconURL() })
        .setTimestamp();

      await interaction.editReply({ embeds: [existingEmbed] });
      return;
    }

    let supportCategory = guild.channels.cache.find(
      channel => channel.name.toLowerCase() === '🎫 tickets' && channel.type === ChannelType.GuildCategory
    );

    if (!supportCategory) {
      try {
        supportCategory = await guild.channels.create({
          name: '🎫 TICKETS',
          type: ChannelType.GuildCategory
        });
      } catch (error) {
        console.error('Erreur création catégorie:', error);
      }
    }

    try {
      const ticketChannel = await guild.channels.create({
        name: ticketName,
        type: ChannelType.GuildText,
        parent: supportCategory?.id,
        permissionOverwrites: [
          {
            id: guild.id,
            deny: [PermissionFlagsBits.ViewChannel]
          },
          {
            id: member.id,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.ReadMessageHistory,
              PermissionFlagsBits.AttachFiles,
              PermissionFlagsBits.EmbedLinks
            ]
          }
        ]
      });

      const ticketId = Math.floor(Math.random() * 999999).toString().padStart(6, '0');
      
      const welcomeEmbed = new EmbedBuilder()
        .setColor('#00D9FF')
        .setTitle('🌌 『 TICKET INITIÉ 』')
        .setDescription(`\`\`\`ansi\n[2;36m╔═══════════════════════════════╗[0m\n[2;36m║[0m  [2;37m✦ SUPPORT QUANTIQUE ACTIVÉ ✦[0m  [2;36m║[0m\n[2;36m╚═══════════════════════════════╝[0m\n\`\`\`\n╭─────────────────────────────╮\n│ **🆔 ID TICKET:** \`#${ticketId}\`\n│ **👤 UTILISATEUR:** ${member.user}\n│ **📅 DATE:** <t:${Math.floor(Date.now() / 1000)}:F>\n│ **⚡ STATUT:** \`🟢 OUVERT\`\n╰─────────────────────────────╯\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n### 🎯 **PROTOCOLE D'ASSISTANCE**\n\n**┌─ ÉTAPE 1:** Sélectionne ta catégorie\n**├─ ÉTAPE 2:** Décris ton problème en détail\n**├─ ÉTAPE 3:** Partage ton code (utilise \`\`\`)\n**└─ ÉTAPE 4:** Attends la réponse d'un mentor\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n### 💎 **INFORMATIONS UTILES**\n\n\`\`\`yaml\nTemps de réponse: < 15 min\nMentors disponibles: 24/7\nLangues: FR / EN\nNiveau: Tous niveaux\n\`\`\`\n\n### ⚠️ **RÈGLES DU TICKET**\n\n✓ Sois précis et détaillé\n✓ Partage le code problématique\n✓ Reste patient et respectueux\n✗ Ne spam pas les mentions\n✗ Ne partage pas d'infos personnelles`)
        .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
        .setImage('https://i.imgur.com/your-futuristic-banner.gif')
        .setFooter({ 
          text: `『 FAC QUANTUM SUPPORT 』• Ticket #${ticketId} • V3.0 Beta`, 
          iconURL: 'https://cdn.discordapp.com/emojis/your-custom-emoji.gif' 
        })
        .setTimestamp();

      const categoryMenu = new StringSelectMenuBuilder()
        .setCustomId('ticket_category')
        .setPlaceholder('🎯 Sélectionne la catégorie de ton problème...')
        .addOptions([
          {
            label: '🐍 Python',
            description: 'Problèmes liés à Python',
            value: 'python',
            emoji: '🐍'
          },
          {
            label: '💛 JavaScript',
            description: 'Problèmes liés à JavaScript/Node.js',
            value: 'javascript',
            emoji: '💛'
          },
          {
            label: '🎨 HTML/CSS',
            description: 'Problèmes de design et frontend',
            value: 'htmlcss',
            emoji: '🎨'
          },
          {
            label: '⚛️ React/Framework',
            description: 'Frameworks modernes (React, Vue, etc.)',
            value: 'frameworks',
            emoji: '⚛️'
          },
          {
            label: '🗄️ Base de données',
            description: 'SQL, MongoDB, Firebase...',
            value: 'database',
            emoji: '🗄️'
          },
          {
            label: '🔧 Git/GitHub',
            description: 'Versioning et collaboration',
            value: 'git',
            emoji: '🔧'
          },
          {
            label: '🐛 Debug/Erreur',
            description: 'Erreurs et bugs à résoudre',
            value: 'debug',
            emoji: '🐛'
          },
          {
            label: '💡 Conseil général',
            description: 'Conseils et orientation',
            value: 'general',
            emoji: '💡'
          }
        ]);

      const categoryRow = new ActionRowBuilder().addComponents(categoryMenu);

      const buttonRow = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('ticket_claim')
            .setLabel('Prendre en charge')
            .setEmoji('🛡️')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId('ticket_close')
            .setLabel('Fermer')
            .setEmoji('🔒')
            .setStyle(ButtonStyle.Danger),
          new ButtonBuilder()
            .setCustomId('ticket_transcript')
            .setLabel('Transcript')
            .setEmoji('📜')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setLabel('Guide Support')
            .setEmoji('📖')
            .setStyle(ButtonStyle.Link)
            .setURL('https://votre-site.com/guide-support')
        );

      await ticketChannel.send({
        content: `╔═══════════════════════════════╗\n║  <@${member.id}> **・BIENVENUE** 🌟  ║\n╚═══════════════════════════════╝\n\n<@&VOTRE_ROLE_MENTOR_ID>`,
        embeds: [welcomeEmbed],
        components: [categoryRow, buttonRow]
      });

      const tipsEmbed = new EmbedBuilder()
        .setColor('#7B2CBF')
        .setTitle('💡 『 ASTUCES POUR UNE AIDE RAPIDE 』')
        .setDescription('```ansi\n[2;35m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n[2;37m   OPTIMISE TON SUPPORT   [0m\n[2;35m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n```\n\n### 📝 **Comment bien expliquer ton problème?**\n\n**1️⃣ CONTEXTE**\n└ Sur quel projet travailles-tu?\n└ Qu\'essaies-tu d\'accomplir?\n\n**2️⃣ PROBLÈME**\n└ Que se passe-t-il actuellement?\n└ Quel message d\'erreur reçois-tu?\n\n**3️⃣ CODE**\n└ Partage le code concerné en utilisant les blocs de code\n\n**4️⃣ ESSAIS**\n└ Qu\'as-tu déjà tenté?\n└ Quel résultat attendais-tu?\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n### 🎨 **Formatage du code**\n\nUtilise les blocs de code Discord pour Python, JS, HTML, CSS\n\n### ⚡ **Réponse plus rapide**\n\n✨ Code bien formaté = aide plus rapide\n✨ Screenshots = compréhension facile\n✨ Contexte clair = solution précise')
        .setFooter({ text: '『 FAC TIPS 』• Améliore ton expérience support' })
        .setTimestamp();

      setTimeout(() => {
        ticketChannel.send({ embeds: [tipsEmbed] });
      }, 2000);

      const confirmEmbed = new EmbedBuilder()
        .setColor('#00FF88')
        .setTitle('✅ 『 TICKET CRÉÉ AVEC SUCCÈS 』')
        .setDescription(`\`\`\`ansi\n[2;32m▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰[0m\n[2;37mINITIALISATION COMPLÈTE[0m\n[2;32m▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰[0m\n\`\`\`\n\n╔═══════════════════════╗\n║  **TON TICKET EST PRÊT**  ║\n╚═══════════════════════╝\n\n🎫 **Accès:** <#${ticketChannel.id}>\n🆔 **ID:** \`#${ticketId}\`\n⏱️ **Créé:** <t:${Math.floor(Date.now() / 1000)}:R>\n\n━━━━━━━━━━━━━━━━━━━━━\n\n**Un mentor va te répondre rapidement!**\nEn attendant, prépare ton code et tes questions. 🚀`)
        .setFooter({ text: '『 FAC QUANTUM SUPPORT 』• Système de tickets nouvelle génération' })
        .setTimestamp();

      await interaction.editReply({ embeds: [confirmEmbed] });

    } catch (error) {
      console.error('Erreur création ticket:', error);
      
      const errorEmbed = new EmbedBuilder()
        .setColor('#FF1744')
        .setTitle('❌ 『 ERREUR SYSTÈME 』')
        .setDescription(`\`\`\`ansi\n[2;31m▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰[0m\n[2;37mERREUR DÉTECTÉE[0m\n[2;31m▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰[0m\n\`\`\`\n\n**Une erreur est survenue lors de la création du ticket.**\n\n🔧 **Solution:**\nVérifie que le bot possède les permissions:\n└ Gérer les salons\n└ Voir les salons\n└ Envoyer des messages\n└ Gérer les permissions\n\n📞 **Contact:** Un administrateur`)
        .setFooter({ text: '『 FAC ERROR HANDLER 』' })
        .setTimestamp();
      
      await interaction.editReply({ embeds: [errorEmbed] });
    }
  },
};
