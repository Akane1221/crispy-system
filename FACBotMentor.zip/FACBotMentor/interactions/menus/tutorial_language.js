const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const tutorials = require('../../data/tutorials.json');

module.exports = {
  id: /^tutorial_language_(beginner|intermediate|advanced)$/,
  async execute(interaction) {
    const customId = interaction.customId;
    const level = customId.split('_')[2];
    const language = interaction.values[0];

    const levelNames = {
      beginner: 'Débutant 🟢',
      intermediate: 'Intermédiaire 🟡',
      advanced: 'Avancé 🔴'
    };

    const languageNames = {
      javascript: 'JavaScript 💻',
      python: 'Python 🐍',
      html_css: 'HTML/CSS 🎨'
    };

    const tutorialList = tutorials[level][language];

    if (!tutorialList || tutorialList.length === 0) {
      await interaction.update({
        content: '❌ Aucun tutoriel trouvé pour cette combinaison.',
        embeds: [],
        components: []
      });
      return;
    }

    const embeds = tutorialList.map((tutorial, index) => {
      const embed = new EmbedBuilder()
        .setColor('#3498db')
        .setTitle(`${index + 1}. ${tutorial.title}`)
        .setDescription(tutorial.description)
        .addFields(
          {
            name: '🔗 Ressources',
            value: tutorial.links.map((link, i) => `[Lien ${i + 1}](${link})`).join('\n'),
            inline: false
          },
          {
            name: '✏️ Exercice Pratique',
            value: tutorial.exercises,
            inline: false
          }
        )
        .setFooter({ text: `${levelNames[level]} - ${languageNames[language]}` });
      
      return embed;
    });

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('back_to_levels')
          .setLabel('⬅️ Retour aux niveaux')
          .setStyle(ButtonStyle.Secondary)
      );

    await interaction.update({
      content: `📚 **Tutoriels ${languageNames[language]} - ${levelNames[level]}**\n\nVoici ${tutorialList.length} tutoriel(s) pour t'aider à progresser:`,
      embeds: embeds.slice(0, 3),
      components: [row]
    });
  },
};
