const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const projectsData = require('../../data/projects.json');

module.exports = {
  id: 'project_select',
  async execute(interaction) {
    const projectId = interaction.values[0];
    const project = projectsData.projects.find(p => p.id === projectId);

    if (!project) {
      await interaction.update({
        content: '❌ Projet non trouvé.',
        embeds: [],
        components: []
      });
      return;
    }

    const difficultyColors = {
      'Débutant': '#2ecc71',
      'Intermédiaire': '#f39c12',
      'Avancé': '#e74c3c'
    };

    const embed = new EmbedBuilder()
      .setColor(difficultyColors[project.difficulty])
      .setTitle(project.title)
      .setDescription(project.description)
      .addFields(
        { name: '📊 Difficulté', value: project.difficulty, inline: true },
        { name: '💻 Langage', value: project.language, inline: true },
        { name: '⏱️ Temps estimé', value: project.estimated_time, inline: true },
        {
          name: '✨ Fonctionnalités à implémenter',
          value: project.features.map(f => `• ${f}`).join('\n'),
          inline: false
        },
        {
          name: '🎯 Compétences développées',
          value: project.skills,
          inline: false
        }
      )
      .setFooter({ text: 'Bonne chance avec ton projet!' })
      .setTimestamp();

    if (project.api) {
      embed.addFields({
        name: '🔌 API Requise',
        value: project.api,
        inline: false
      });
    }

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('mark_project_started')
          .setLabel('🚀 Commencer ce projet')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('back_to_projects')
          .setLabel('⬅️ Retour aux projets')
          .setStyle(ButtonStyle.Secondary)
      );

    await interaction.update({
      embeds: [embed],
      components: [row]
    });
  },
};
