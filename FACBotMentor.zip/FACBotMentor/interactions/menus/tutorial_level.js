const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const tutorials = require('../../data/tutorials.json');

module.exports = {
  id: 'tutorial_level',
  async execute(interaction) {
    const level = interaction.values[0];
    const levelNames = {
      beginner: 'Débutant 🟢',
      intermediate: 'Intermédiaire 🟡',
      advanced: 'Avancé 🔴'
    };

    const embed = new EmbedBuilder()
      .setColor('#3498db')
      .setTitle(`📚 Tutoriels Niveau ${levelNames[level]}`)
      .setDescription('Choisis le langage que tu veux apprendre!\n')
      .setFooter({ text: 'Sélectionne un langage ci-dessous' })
      .setTimestamp();

    const languages = Object.keys(tutorials[level]);
    const languageEmojis = {
      javascript: '💻',
      python: '🐍',
      html_css: '🎨'
    };

    const languageNames = {
      javascript: 'JavaScript',
      python: 'Python',
      html_css: 'HTML/CSS'
    };

    languages.forEach(lang => {
      const tutorialCount = tutorials[level][lang].length;
      embed.addFields({
        name: `${languageEmojis[lang]} ${languageNames[lang]}`,
        value: `${tutorialCount} tutoriel(s) disponible(s)`,
        inline: true
      });
    });

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId(`tutorial_language_${level}`)
      .setPlaceholder('🎯 Choisis un langage')
      .addOptions(
        languages.map(lang => ({
          label: languageNames[lang],
          description: `Voir les tutoriels ${languageNames[lang]}`,
          value: lang,
          emoji: languageEmojis[lang]
        }))
      );

    const row = new ActionRowBuilder().addComponents(selectMenu);

    await interaction.update({
      embeds: [embed],
      components: [row]
    });
  },
};
