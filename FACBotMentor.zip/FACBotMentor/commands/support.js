
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('support')
    .setDescription('🛡️ Système de support premium avec IA et experts'),
  
  async execute(interaction) {
    const mainEmbed = new EmbedBuilder()
      .setColor('#FF006E')
      .setTitle('🛡️ SUPPORT PREMIUM 360°')
      .setDescription('```ansi\n[2;35m╔═══════════════════════════════════════════╗\n║  [1;37mSYSTÈME DE SUPPORT NOUVELLE GÉNÉRATION[0m  [2;35m║\n╚═══════════════════════════════════════════╝[0m\n```\n\n> *Support ultra-rapide avec IA + Experts humains*\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n### ⚡ **FONCTIONNALITÉS EXCLUSIVES**\n\n```yaml\n🤖 IA Assistant:      Réponses instantanées 24/7\n👨‍💻 Experts Humains:   Mentors dédiés disponibles\n📊 Tracking:          Suivi en temps réel\n🔒 Privé & Sécurisé:  Conversations chiffrées\n⏱️ SLA:              Réponse sous 10 minutes\n🌐 Multi-langues:     FR, EN, ES supportés\n```\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n### 🎯 **QUAND CRÉER UN TICKET?**\n\n╭─────────────────────────────────╮\n│ **🐛 Debug**    │ Code bloqué     │\n│ **💡 Concept**  │ Besoin d\'aide   │\n│ **🚀 Projet**   │ Conseils tech   │\n│ **⚡ Optim**     │ Perf & qualité  │\n│ **🎓 Learn**    │ Explication     │\n│ **🔧 Config**   │ Setup & tools   │\n╰─────────────────────────────────╯\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n### 📈 **MÉTRIQUES LIVE**\n\n```ansi\n[2;32m●[0m Experts en ligne:    [1;37m12[0m\n[2;33m●[0m Tickets actifs:      [1;37m5[0m\n[2;36m●[0m Temps de réponse:    [1;37m8 min[0m\n[2;35m●[0m Satisfaction:        [1;37m99.2%[0m\n```\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
      .addFields(
        { 
          name: '🌟 PREMIUM FEATURES', 
          value: '```\n▰ Écran partagé en live\n▰ Sessions 1-on-1 planifiées\n▰ Code review approfondie\n▰ Accès ressources VIP\n```',
          inline: true
        },
        { 
          name: '🏆 VOTRE PROGRESSION', 
          value: '```\n▰ Tickets résolus: 0\n▰ Temps économisé: 0h\n▰ Niveau: Débutant\n▰ XP: 0/100\n```',
          inline: true
        }
      )
      .setImage('https://cdn.discordapp.com/attachments/placeholder-support-banner.gif')
      .setFooter({ 
        text: '『 FAC PREMIUM SUPPORT 』• Powered by AI & Human Intelligence',
        iconURL: interaction.client.user.displayAvatarURL()
      })
      .setTimestamp();

    const buttonRow = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('create_support_ticket')
          .setLabel('Créer un Ticket')
          .setEmoji('🎫')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('view_my_tickets')
          .setLabel('Mes Tickets')
          .setEmoji('📋')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('ticket_stats')
          .setLabel('Statistiques')
          .setEmoji('📊')
          .setStyle(ButtonStyle.Secondary)
      );

    const extraRow = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('support_ai_chat')
          .setLabel('Chat IA Instantané')
          .setEmoji('🤖')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setLabel('Devenir Expert')
          .setEmoji('👑')
          .setStyle(ButtonStyle.Link)
          .setURL('https://replit.com')
      );

    await interaction.reply({
      embeds: [mainEmbed],
      components: [buttonRow, extraRow]
    });
  },
};
