
const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('delete')
    .setDescription('🗑️ Supprime tous les rôles non-essentiels du serveur')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    
    const guild = interaction.guild;
    const roles = guild.roles.cache.filter(role => 
      !role.managed && // Ne pas supprimer les rôles de bot
      role.id !== guild.id && // Ne pas supprimer @everyone
      role.position < guild.members.me.roles.highest.position // Ne pas supprimer les rôles supérieurs
    );
    
    if (roles.size === 0) {
      const noRolesEmbed = new EmbedBuilder()
        .setColor('#FF6B6B')
        .setTitle('```ansi\n\u001b[2;31m╔════════════════════════════════════╗\n║      ⚠️  AUCUN RÔLE À SUPPRIMER  ⚠️   ║\n╚════════════════════════════════════╝\u001b[0m\n```')
        .setDescription('Il n\'y a aucun rôle supprimable sur ce serveur.\n\n> Les rôles de bots et @everyone sont protégés.')
        .setTimestamp();
      
      return await interaction.editReply({ embeds: [noRolesEmbed] });
    }
    
    // Analyser les rôles
    const roleStats = {
      total: roles.size,
      withMembers: 0,
      empty: 0,
      hoisted: 0,
      mentionable: 0
    };
    
    const rolesList = [];
    for (const [, role] of roles) {
      const memberCount = role.members.size;
      if (memberCount > 0) roleStats.withMembers++;
      else roleStats.empty++;
      if (role.hoist) roleStats.hoisted++;
      if (role.mentionable) roleStats.mentionable++;
      
      rolesList.push({
        name: role.name,
        members: memberCount,
        color: role.hexColor
      });
    }
    
    // Trier par nombre de membres
    rolesList.sort((a, b) => b.members - a.members);
    
    // Créer la liste des rôles (top 15)
    const topRoles = rolesList.slice(0, 15).map((r, i) => 
      `${i + 1}. **${r.name}** • ${r.members} membre${r.members > 1 ? 's' : ''}`
    ).join('\n');
    
    const confirmEmbed = new EmbedBuilder()
      .setColor('#FFA500')
      .setTitle('```ansi\n\u001b[2;33m╔════════════════════════════════════════════╗\n║      ⚠️  CONFIRMATION REQUISE  ⚠️          ║\n╚════════════════════════════════════════════╝\u001b[0m\n```')
      .setDescription(`
### 🗑️ **SUPPRESSION DE RÔLES**

\`\`\`ansi
\u001b[2;31m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\u001b[0m
\`\`\`

**📊 STATISTIQUES**

🔢 **Total de rôles:** ${roleStats.total}
👥 **Avec membres:** ${roleStats.withMembers}
📭 **Vides:** ${roleStats.empty}
📌 **Affichés séparément:** ${roleStats.hoisted}
🔔 **Mentionnables:** ${roleStats.mentionable}

\`\`\`ansi
\u001b[2;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\u001b[0m
\`\`\`

### 📋 **TOP ${Math.min(15, rolesList.length)} RÔLES**

${topRoles}

${rolesList.length > 15 ? `\n*... et ${rolesList.length - 15} autres rôles*` : ''}

\`\`\`ansi
\u001b[2;31m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\u001b[0m
\`\`\`

⚠️ **ATTENTION:** Cette action est **IRRÉVERSIBLE** !

> Tous ces rôles seront **définitivement supprimés**.
> Les membres perdront leurs rôles.
      `)
      .setFooter({ text: '⚠️ Réfléchissez bien avant de confirmer' })
      .setTimestamp();
    
    const confirmButton = new ButtonBuilder()
      .setCustomId('confirm_delete_roles')
      .setLabel('✅ Confirmer la suppression')
      .setStyle(ButtonStyle.Danger);
    
    const cancelButton = new ButtonBuilder()
      .setCustomId('cancel_delete_roles')
      .setLabel('❌ Annuler')
      .setStyle(ButtonStyle.Secondary);
    
    const row = new ActionRowBuilder().addComponents(confirmButton, cancelButton);
    
    const response = await interaction.editReply({ 
      embeds: [confirmEmbed],
      components: [row]
    });
    
    const filter = i => i.user.id === interaction.user.id;
    const collector = response.createMessageComponentCollector({ filter, time: 30000 });
    
    collector.on('collect', async i => {
      if (i.customId === 'cancel_delete_roles') {
        const cancelEmbed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('```ansi\n\u001b[2;32m╔════════════════════════════════════╗\n║      ✅  OPÉRATION ANNULÉE  ✅      ║\n╚════════════════════════════════════╝\u001b[0m\n```')
          .setDescription('La suppression des rôles a été annulée.\n\n> Aucun rôle n\'a été modifié.')
          .setTimestamp();
        
        await i.update({ embeds: [cancelEmbed], components: [] });
        collector.stop();
        return;
      }
      
      if (i.customId === 'confirm_delete_roles') {
        await i.update({ 
          embeds: [new EmbedBuilder()
            .setColor('#FF6B6B')
            .setTitle('```ansi\n\u001b[2;31m╔════════════════════════════════════╗\n║   🗑️  SUPPRESSION EN COURS...  🗑️   ║\n╚════════════════════════════════════╝\u001b[0m\n```')
            .setDescription('⏳ Suppression des rôles en cours...\n\n```ansi\n\u001b[2;33m▰▰▰▰▰░░░░░░░░░░░░░░░ 0%\u001b[0m\n```')
          ],
          components: []
        });
        
        let deleted = 0;
        let failed = 0;
        const total = roles.size;
        const deletedRoles = [];
        
        let index = 0;
        for (const [, role] of roles) {
          try {
            const roleName = role.name;
            const memberCount = role.members.size;
            
            await role.delete('Nettoyage via /delete');
            deleted++;
            deletedRoles.push({ name: roleName, members: memberCount });
            
            // Mise à jour de la progression
            const progress = Math.round(((index + 1) / total) * 100);
            const progressBar = '▰'.repeat(Math.floor(progress / 5)) + '░'.repeat(20 - Math.floor(progress / 5));
            
            if ((index + 1) % 5 === 0 || index === total - 1) {
              const updateEmbed = new EmbedBuilder()
                .setColor('#FF6B6B')
                .setTitle('```ansi\n\u001b[2;31m╔════════════════════════════════════╗\n║   🗑️  SUPPRESSION EN COURS...  🗑️   ║\n╚════════════════════════════════════╝\u001b[0m\n```')
                .setDescription(`⏳ Suppression des rôles...\n\n\`\`\`ansi\n\u001b[2;33m${progressBar} ${progress}%\u001b[0m\n\`\`\`\n\n✅ **Supprimés:** ${deleted}\n❌ **Échecs:** ${failed}\n📊 **Progression:** ${index + 1}/${total}`);
              
              await i.editReply({ embeds: [updateEmbed] });
            }
            
            await new Promise(resolve => setTimeout(resolve, 200));
          } catch (error) {
            console.error(`Erreur suppression rôle ${role.name}:`, error);
            failed++;
          }
          index++;
        }
        
        const topDeleted = deletedRoles.slice(0, 10).map((r, i) => 
          `${i + 1}. **${r.name}** • ${r.members} membre${r.members > 1 ? 's' : ''}`
        ).join('\n');
        
        const finalEmbed = new EmbedBuilder()
          .setColor('#00FF00')
          .setTitle('```ansi\n\u001b[2;32m╔════════════════════════════════════╗\n║      ✅  NETTOYAGE TERMINÉ  ✅      ║\n╚════════════════════════════════════╝\u001b[0m\n```')
          .setDescription(`
### 📊 **RÉSULTAT DE LA SUPPRESSION**

\`\`\`ansi
\u001b[2;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\u001b[0m
\`\`\`

✅ **Rôles supprimés:** ${deleted}
❌ **Échecs:** ${failed}
📋 **Total traité:** ${total}
📈 **Taux de réussite:** ${total > 0 ? Math.round((deleted / total) * 100) : 0}%

\`\`\`ansi
\u001b[2;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\u001b[0m
\`\`\`

### 🗑️ **RÔLES SUPPRIMÉS** (top 10)

${topDeleted}

${deletedRoles.length > 10 ? `\n*... et ${deletedRoles.length - 10} autres rôles*` : ''}

\`\`\`ansi
\u001b[2;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\u001b[0m
\`\`\`

> 💡 Utilise \`/create\` pour recréer une structure propre!
          `)
          .setFooter({ text: '✨ FAC Bot • Nettoyage terminé' })
          .setTimestamp();
        
        await i.editReply({ embeds: [finalEmbed] });
        collector.stop();
      }
    });
    
    collector.on('end', collected => {
      if (collected.size === 0) {
        const timeoutEmbed = new EmbedBuilder()
          .setColor('#FFA500')
          .setTitle('```ansi\n\u001b[2;33m╔════════════════════════════════════╗\n║      ⏱️  TEMPS ÉCOULÉ  ⏱️           ║\n╚════════════════════════════════════╝\u001b[0m\n```')
          .setDescription('La confirmation a expiré (30s).\n\n> Aucun rôle n\'a été supprimé.')
          .setTimestamp();
        
        interaction.editReply({ embeds: [timeoutEmbed], components: [] }).catch(() => {});
      }
    });
  },
};
