const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ressources')
    .setDescription('🔗 Liens vers des ressources d\'apprentissage'),
  
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor('#27ae60')
      .setTitle('🔗 Ressources d\'Apprentissage')
      .setDescription('Voici une sélection des meilleures ressources pour apprendre à coder!\n')
      .addFields(
        {
          name: '📚 Documentation Officielle',
          value: '[MDN Web Docs](https://developer.mozilla.org/fr/) - Documentation complète web\n[Python.org](https://docs.python.org/fr/3/) - Documentation Python\n[W3Schools](https://www.w3schools.com/) - Tutoriels et références',
          inline: false
        },
        {
          name: '🎓 Cours en Ligne Gratuits',
          value: '[freeCodeCamp](https://www.freecodecamp.org/) - Cours complets gratuits\n[Codecademy](https://www.codecademy.com/) - Cours interactifs\n[OpenClassrooms](https://openclassrooms.com/fr/) - Cours en français',
          inline: false
        },
        {
          name: '💻 Pratique et Exercices',
          value: '[Codewars](https://www.codewars.com/) - Défis de programmation\n[LeetCode](https://leetcode.com/) - Algorithmes et structures de données\n[HackerRank](https://www.hackerrank.com/) - Challenges de code',
          inline: false
        },
        {
          name: '🎥 Chaînes YouTube (FR)',
          value: '[Grafikart](https://www.youtube.com/c/grafikart) - Tutoriels web\n[Underscore_](https://www.youtube.com/c/Underscore_) - Développement général\n[Le Designer du Web](https://www.youtube.com/c/LeDesignerduWeb) - HTML/CSS/JS',
          inline: false
        },
        {
          name: '🛠️ Outils Utiles',
          value: '[GitHub](https://github.com/) - Hébergement de code\n[CodePen](https://codepen.io/) - Éditeur en ligne\n[Replit](https://replit.com/) - IDE en ligne collaboratif',
          inline: false
        }
      )
      .setFooter({ text: 'Clique sur les liens pour accéder aux ressources' })
      .setTimestamp();

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setLabel('📖 MDN Docs')
          .setURL('https://developer.mozilla.org/fr/')
          .setStyle(ButtonStyle.Link),
        new ButtonBuilder()
          .setLabel('🎓 freeCodeCamp')
          .setURL('https://www.freecodecamp.org/')
          .setStyle(ButtonStyle.Link),
        new ButtonBuilder()
          .setLabel('💻 GitHub')
          .setURL('https://github.com/')
          .setStyle(ButtonStyle.Link)
      );

    await interaction.reply({
      embeds: [embed],
      components: [row]
    });
  },
};
