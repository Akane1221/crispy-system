const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('aide')
    .setDescription('❓ Affiche l\'aide et les commandes disponibles'),
  
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor('#9b59b6')
      .setTitle('❓ Guide d\'utilisation - FAC Bot')
      .setDescription('Bienvenue sur FAC Bot! Voici comment utiliser le bot pour apprendre à coder.\n')
      .addFields(
        {
          name: '📚 Commandes d\'Apprentissage',
          value: '`/tutoriels` - Accède aux tutoriels par niveau et langage\n`/projets` - Découvre des projets pratiques à réaliser\n`/ressources` - Liens vers des sites et cours recommandés',
          inline: false
        },
        {
          name: '🎫 Support',
          value: '`/support` - Crée un ticket pour obtenir de l\'aide\n`/question` - Pose une question rapide à la communauté',
          inline: false
        },
        {
          name: '📊 Progression',
          value: '`/profil` - Voir ton profil et ta progression\n`/badge` - Voir tes badges et accomplissements',
          inline: false
        },
        {
          name: '💡 Conseils',
          value: '• Pratique régulièrement\n• N\'hésite pas à demander de l\'aide\n• Fais des projets pour apprendre\n• Partage tes réalisations avec la communauté',
          inline: false
        }
      )
      .setFooter({ text: 'FAC Bot - Ton compagnon d\'apprentissage' })
      .setTimestamp();

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('start_learning')
          .setLabel('🎓 Commencer à apprendre')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('create_support_ticket')
          .setLabel('🎫 Créer un ticket')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setLabel('📖 Documentation')
          .setURL('https://developer.mozilla.org/fr/')
          .setStyle(ButtonStyle.Link)
      );

    await interaction.reply({
      embeds: [embed],
      components: [row]
    });
  },
};
