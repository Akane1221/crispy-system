
const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('create')
    .setDescription('✨ Crée une structure de rôles professionnelle et complète')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    
    const guild = interaction.guild;
    
    const progressEmbed = new EmbedBuilder()
      .setColor('#00D9FF')
      .setTitle('```ansi\n\u001b[2;36m╔═══════════════════════════════════════════╗\n║      ✨  CRÉATION EN COURS...  ✨        ║\n╚═══════════════════════════════════════════╝\u001b[0m\n```')
      .setDescription('⏳ Création de la structure complète des rôles...\n\n```ansi\n\u001b[2;33m▰▰▰▰▰▰▰▰▰▰▰░░░░░░░░░░ 0%\u001b[0m\n```');
    
    await interaction.editReply({ embeds: [progressEmbed] });
    
    const roles = [
      // ═══════════ ADMINISTRATION ═══════════
      { name: '━━━━━━ 👑 STAFF ━━━━━━', color: '#2F3136', hoist: false },
      { name: '👑・FONDATEUR', color: '#FF0080', hoist: true, mentionable: true, permissions: ['Administrator'] },
      { name: '⚡・CO-FONDATEUR', color: '#FF1744', hoist: true, mentionable: true, permissions: ['Administrator'] },
      { name: '🛡️・ADMINISTRATEUR', color: '#E91E63', hoist: true, mentionable: true, permissions: ['ManageGuild', 'ManageRoles', 'ManageChannels', 'KickMembers', 'BanMembers'] },
      { name: '🔨・MODÉRATEUR', color: '#FF6E40', hoist: true, mentionable: true, permissions: ['ManageMessages', 'KickMembers', 'MuteMembers'] },
      { name: '🎯・HELPER', color: '#FF9800', hoist: true, mentionable: true, permissions: ['ManageMessages'] },
      
      // ═══════════ BOOSTERS & VIP ═══════════
      { name: '━━━━━━ 💎 VIP ━━━━━━', color: '#2F3136', hoist: false },
      { name: '💖・BOOSTER', color: '#F47FFF', hoist: true, mentionable: false },
      { name: '🌟・PREMIUM', color: '#FFD700', hoist: true, mentionable: false },
      { name: '👑・VIP', color: '#00E5FF', hoist: true, mentionable: false },
      
      // ═══════════ NIVEAUX D'EXPÉRIENCE ═══════════
      { name: '━━━━━━ 📊 NIVEAUX ━━━━━━', color: '#2F3136', hoist: false },
      { name: '🏆・LÉGENDE (LVL 100+)', color: '#FFD700', hoist: true },
      { name: '💎・MAÎTRE (LVL 75+)', color: '#00E5FF', hoist: true },
      { name: '💠・EXPERT (LVL 50+)', color: '#B388FF', hoist: true },
      { name: '⚔️・AVANCÉ (LVL 30+)', color: '#7C4DFF', hoist: true },
      { name: '🌟・INTERMÉDIAIRE (LVL 15+)', color: '#FFD740', hoist: true },
      { name: '🔰・DÉBUTANT (LVL 5+)', color: '#69F0AE', hoist: true },
      { name: '🆕・NOUVEAU', color: '#90A4AE', hoist: true },
      
      // ═══════════ LANGAGES DE PROGRAMMATION ═══════════
      { name: '━━━━━━ 💻 LANGAGES ━━━━━━', color: '#2F3136', hoist: false },
      { name: '🐍・Python', color: '#3776AB', hoist: false },
      { name: '💛・JavaScript', color: '#F7DF1E', hoist: false },
      { name: '📘・TypeScript', color: '#3178C6', hoist: false },
      { name: '☕・Java', color: '#007396', hoist: false },
      { name: '🔷・C++', color: '#00599C', hoist: false },
      { name: '💜・C#', color: '#239120', hoist: false },
      { name: '🐘・PHP', color: '#777BB4', hoist: false },
      { name: '💎・Ruby', color: '#CC342D', hoist: false },
      { name: '🦀・Rust', color: '#CE422B', hoist: false },
      { name: '🔵・Go', color: '#00ADD8', hoist: false },
      { name: '🟣・Kotlin', color: '#7F52FF', hoist: false },
      { name: '🔶・Swift', color: '#FA7343', hoist: false },
      
      // ═══════════ FRAMEWORKS & TECHNOLOGIES ═══════════
      { name: '━━━━━━ ⚙️ FRAMEWORKS ━━━━━━', color: '#2F3136', hoist: false },
      { name: '⚛️・React', color: '#61DAFB', hoist: false },
      { name: '💚・Vue.js', color: '#4FC08D', hoist: false },
      { name: '🅰️・Angular', color: '#DD0031', hoist: false },
      { name: '⚡・Next.js', color: '#000000', hoist: false },
      { name: '🟢・Node.js', color: '#68A063', hoist: false },
      { name: '🐍・Django', color: '#092E20', hoist: false },
      { name: '🔥・Flask', color: '#000000', hoist: false },
      { name: '🌸・Spring', color: '#6DB33F', hoist: false },
      { name: '💎・Laravel', color: '#FF2D20', hoist: false },
      
      // ═══════════ SPÉCIALITÉS ═══════════
      { name: '━━━━━━ 🎨 SPÉCIALITÉS ━━━━━━', color: '#2F3136', hoist: false },
      { name: '🎨・Frontend', color: '#E34C26', hoist: false },
      { name: '⚙️・Backend', color: '#68A063', hoist: false },
      { name: '📱・Mobile', color: '#3DDC84', hoist: false },
      { name: '🗄️・Database', color: '#4479A1', hoist: false },
      { name: '☁️・DevOps', color: '#FF9900', hoist: false },
      { name: '🔒・Cybersécurité', color: '#FF0000', hoist: false },
      { name: '🤖・Machine Learning', color: '#FF6F00', hoist: false },
      { name: '🎮・Game Dev', color: '#FF00FF', hoist: false },
      { name: '🌐・Web3 / Blockchain', color: '#627EEA', hoist: false },
      
      // ═══════════ COMMUNAUTÉ ═══════════
      { name: '━━━━━━ 🌍 COMMUNAUTÉ ━━━━━━', color: '#2F3136', hoist: false },
      { name: '🎓・Mentor', color: '#00BCD4', hoist: false, mentionable: true },
      { name: '✨・Actif', color: '#4CAF50', hoist: false },
      { name: '🎤・Vocaux', color: '#9C27B0', hoist: false },
      { name: '🎨・Créateur de contenu', color: '#FF5722', hoist: false },
      { name: '📝・Rédacteur', color: '#795548', hoist: false },
      
      // ═══════════ NOTIFICATIONS ═══════════
      { name: '━━━━━━ 🔔 NOTIFICATIONS ━━━━━━', color: '#2F3136', hoist: false },
      { name: '📢・Annonces', color: '#607D8B', hoist: false, mentionable: true },
      { name: '🎉・Événements', color: '#FF4081', hoist: false, mentionable: true },
      { name: '📰・News Tech', color: '#2196F3', hoist: false, mentionable: true },
      { name: '🎁・Giveaways', color: '#FFEB3B', hoist: false, mentionable: true },
    ];
    
    let created = 0;
    let failed = 0;
    let skipped = 0;
    const total = roles.length;
    
    for (let i = 0; i < roles.length; i++) {
      const roleData = roles[i];
      
      // Vérifier si le rôle existe déjà
      const existingRole = guild.roles.cache.find(r => r.name === roleData.name);
      if (existingRole) {
        skipped++;
        continue;
      }
      
      try {
        const roleOptions = {
          name: roleData.name,
          color: roleData.color,
          hoist: roleData.hoist || false,
          mentionable: roleData.mentionable || false
        };
        
        if (roleData.permissions) {
          roleOptions.permissions = roleData.permissions;
        }
        
        await guild.roles.create(roleOptions);
        created++;
        
        // Mise à jour de la progression
        const progress = Math.round(((i + 1) / total) * 100);
        const progressBar = '▰'.repeat(Math.floor(progress / 5)) + '░'.repeat(20 - Math.floor(progress / 5));
        
        if ((i + 1) % 5 === 0 || i === roles.length - 1) {
          const updateEmbed = new EmbedBuilder()
            .setColor('#00D9FF')
            .setTitle('```ansi\n\u001b[2;36m╔═══════════════════════════════════════════╗\n║      ✨  CRÉATION EN COURS...  ✨        ║\n╚═══════════════════════════════════════════╝\u001b[0m\n```')
            .setDescription(`⏳ Création des rôles...\n\n\`\`\`ansi\n\u001b[2;33m${progressBar} ${progress}%\u001b[0m\n\`\`\`\n\n✅ **Créés:** ${created}\n⏭️ **Ignorés:** ${skipped}\n❌ **Échecs:** ${failed}\n📊 **Progression:** ${i + 1}/${total}`);
          
          await interaction.editReply({ embeds: [updateEmbed] });
        }
        
        await new Promise(resolve => setTimeout(resolve, 250));
      } catch (error) {
        console.error(`Erreur création rôle ${roleData.name}:`, error);
        failed++;
      }
    }
    
    const categories = [
      { name: '👑 STAFF', count: 5 },
      { name: '💎 VIP', count: 3 },
      { name: '📊 NIVEAUX', count: 7 },
      { name: '💻 LANGAGES', count: 12 },
      { name: '⚙️ FRAMEWORKS', count: 9 },
      { name: '🎨 SPÉCIALITÉS', count: 9 },
      { name: '🌍 COMMUNAUTÉ', count: 5 },
      { name: '🔔 NOTIFICATIONS', count: 4 }
    ];
    
    const categoriesText = categories.map(cat => `**${cat.name}** • ${cat.count} rôles`).join('\n');
    
    const finalEmbed = new EmbedBuilder()
      .setColor('#00FF00')
      .setTitle('```ansi\n\u001b[2;32m╔═══════════════════════════════════════════╗\n║      ✅  CRÉATION TERMINÉE !  ✅         ║\n╚═══════════════════════════════════════════╝\u001b[0m\n```')
      .setDescription(`
### 📊 **RÉSULTAT DE LA CRÉATION**

\`\`\`ansi
\u001b[2;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\u001b[0m
\`\`\`

✅ **Rôles créés:** ${created}
⏭️ **Rôles ignorés:** ${skipped} *(déjà existants)*
❌ **Échecs:** ${failed}
📋 **Total:** ${total} rôles

\`\`\`ansi
\u001b[2;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\u001b[0m
\`\`\`

### 📚 **STRUCTURE CRÉÉE**

${categoriesText}

\`\`\`ansi
\u001b[2;35m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\u001b[0m
\`\`\`

> 🎯 Structure professionnelle et complète prête à l'emploi!
> 💡 Utilise \`/delete\` pour nettoyer avant de recréer si besoin.
      `)
      .setFooter({ text: '✨ FAC Bot • Structure de rôles optimisée' })
      .setTimestamp();
    
    await interaction.editReply({ embeds: [finalEmbed] });
  },
};
