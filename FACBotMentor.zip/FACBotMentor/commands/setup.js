
const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('🌌 CRÉATION ULTRA FUTURISTE DU SERVEUR - JAMAIS VU!')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    
    const guild = interaction.guild;
    
    try {
      // ═══════════════════════════════════════════════════════════
      // ÉTAPE 1: CRÉATION DES RÔLES FUTURISTES AVEC DÉGRADÉS
      // ═══════════════════════════════════════════════════════════
      
      await interaction.editReply('```ansi\n[2;36m╔════════════════════════════════════╗\n║  🌌 INITIALISATION QUANTIQUE...  ║\n╚════════════════════════════════════╝[0m\n```');
      
      const roles = [
        { name: '👑・FONDATEUR', color: '#FF0080', hoist: true, mentionable: true },
        { name: '⚡・ADMIN SUPREME', color: '#FF1744', hoist: true, mentionable: true },
        { name: '🛡️・MODÉRATEUR ELITE', color: '#FF6E40', hoist: true, mentionable: true },
        { name: '🎓・MENTOR LEGENDAIRE', color: '#FFD700', hoist: true, mentionable: true },
        { name: '💎・CODEUR DIAMANT', color: '#00E5FF', hoist: true, mentionable: false },
        { name: '🔮・CODEUR PLATINE', color: '#B388FF', hoist: true, mentionable: false },
        { name: '⚔️・CODEUR OR', color: '#FFD740', hoist: true, mentionable: false },
        { name: '🌟・CODEUR ARGENT', color: '#C0C0C0', hoist: true, mentionable: false },
        { name: '🔰・APPRENTI', color: '#69F0AE', hoist: true, mentionable: false },
        { name: '━━━━━━━━━━━', color: '#2F3136', hoist: false, mentionable: false },
        { name: '🐍・Python Dev', color: '#3776AB', hoist: false, mentionable: false },
        { name: '💛・JavaScript Dev', color: '#F7DF1E', hoist: false, mentionable: false },
        { name: '⚛️・React Dev', color: '#61DAFB', hoist: false, mentionable: false },
        { name: '🎨・Frontend Dev', color: '#E34C26', hoist: false, mentionable: false },
        { name: '⚙️・Backend Dev', color: '#68A063', hoist: false, mentionable: false },
        { name: '🗄️・Database Expert', color: '#4479A1', hoist: false, mentionable: false },
        { name: '📱・Mobile Dev', color: '#A4C639', hoist: false, mentionable: false },
      ];
      
      const createdRoles = [];
      for (const roleData of roles) {
        const role = await guild.roles.create({
          name: roleData.name,
          color: roleData.color,
          hoist: roleData.hoist,
          mentionable: roleData.mentionable,
        });
        createdRoles.push(role);
        await new Promise(resolve => setTimeout(resolve, 400));
      }
      
      // ═══════════════════════════════════════════════════════════
      // ÉTAPE 2: CATÉGORIE CENTRALE - HUB QUANTIQUE
      // ═══════════════════════════════════════════════════════════
      
      await interaction.editReply('```ansi\n[2;35m╔════════════════════════════════════╗\n║   🔮 CRÉATION HUB QUANTIQUE...   ║\n╚════════════════════════════════════╝[0m\n```');
      
      const hubCategory = await guild.channels.create({
        name: '🌌・HUB QUANTIQUE',
        type: ChannelType.GuildCategory,
      });
      
      // Salon de bienvenue ULTRA stylé
      const welcomeChannel = await guild.channels.create({
        name: '🚀・portail-dimensionnel',
        type: ChannelType.GuildText,
        parent: hubCategory.id,
        topic: '🌌 POINT D\'ENTRÉE VERS LA DIMENSION CODE',
      });
      
      const welcomeEmbed = new EmbedBuilder()
        .setColor('#00FFF0')
        .setTitle('```ansi\n[2;36m╔═══════════════════════════════════════════╗\n║                                           ║\n║    🌌  BIENVENUE DANS LE FUTUR  🌌     ║\n║                                           ║\n╚═══════════════════════════════════════════╝[0m\n```')
        .setDescription('```ansi\n[2;35m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀[0m\n```\n\n## 🔮 **TU VIENS D\'ENTRER DANS LA MATRICE**\n\n> *Une académie révolutionnaire où le code devient art*\n\n```ansi\n[2;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n[1;37m           NAVIGATION QUANTIQUE            [0m\n[2;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n```\n\n### 🎯 **ACCÈS RAPIDE**\n\n<#' + welcomeChannel.id + '> → Tu es ici\n📚 **Tutoriels** → Utilise `/tutoriels`\n🚀 **Projets** → Utilise `/projets`\n🎫 **Support** → Utilise `/support`\n\n```ansi\n[2;35m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n```\n\n### ⚡ **SYSTÈME DE PROGRESSION**\n\n🔰 **Apprenti** → 🌟 **Argent** → ⚔️ **Or** → 🔮 **Platine** → 💎 **Diamant**\n\n*Gagne des XP en codant et en aidant la communauté*\n\n```ansi\n[2;36m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀[0m\n```')
        .setImage('https://i.imgur.com/placeholder.png')
        .setFooter({ text: '⚡ Propulsé par FAC Bot・Système Quantique v2.0' })
        .setTimestamp();
      
      const welcomeButtons = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('start_learning')
            .setLabel('🎓 DÉMARRER L\'APPRENTISSAGE')
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId('create_support_ticket')
            .setLabel('🎫 SUPPORT INSTANTANÉ')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setLabel('📖 GUIDE COMPLET')
            .setStyle(ButtonStyle.Link)
            .setURL('https://discord.com')
        );
      
      await welcomeChannel.send({ embeds: [welcomeEmbed], components: [welcomeButtons] });
      
      // Règles FUTURISTES
      const rulesChannel = await guild.channels.create({
        name: '📜・protocoles-matriciels',
        type: ChannelType.GuildText,
        parent: hubCategory.id,
        topic: '⚖️ LES LOIS DE LA MATRICE CODE',
        permissionOverwrites: [{ id: guild.id, deny: [PermissionFlagsBits.SendMessages] }],
      });
      
      const rulesEmbed = new EmbedBuilder()
        .setColor('#FF0080')
        .setTitle('```ansi\n[2;31m╔═══════════════════════════════════════════╗\n║      ⚖️  PROTOCOLES MATRICIELS  ⚖️      ║\n╚═══════════════════════════════════════════╝[0m\n```')
        .setDescription('```ansi\n[2;35m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀[0m\n```\n\n## 🛡️ **LES 10 COMMANDEMENTS DU CODE**\n\n```ansi\n[2;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n```\n\n### 1️⃣ **RESPECT ABSOLU**\n> Traite chaque codeur comme un maître, peu importe son niveau\n\n### 2️⃣ **ENTRAIDE QUANTIQUE**\n> Le savoir partagé se multiplie à l\'infini\n\n### 3️⃣ **ZÉRO SPAM**\n> Chaque message doit avoir de la valeur\n\n### 4️⃣ **FORMAT CODE**\n> Utilise TOUJOURS les blocs de code ```\n\n### 5️⃣ **CRÉDIT AUX SOURCES**\n> Mentionne toujours l\'origine du code partagé\n\n### 6️⃣ **SALONS DÉDIÉS**\n> Chaque discussion dans son canal quantique\n\n### 7️⃣ **LANGUE FRANÇAISE**\n> Communication principale en français\n\n### 8️⃣ **PAS DE PIRATAGE**\n> Seulement du code éthique et légal\n\n### 9️⃣ **FEEDBACK CONSTRUCTIF**\n> Critique le code, pas le codeur\n\n### 🔟 **AMUSEZ-VOUS**\n> Coder doit rester un plaisir!\n\n```ansi\n[2;31m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n[1;37m     ⚠️  NON-RESPECT = BANNISSEMENT  ⚠️    [0m\n[2;31m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n```')
        .setFooter({ text: '⚖️ Accepter ces règles = Rejoindre la matrice' })
        .setTimestamp();
      
      await rulesChannel.send({ embeds: [rulesEmbed] });
      
      // ═══════════════════════════════════════════════════════════
      // ÉTAPE 3: ACADÉMIE - SALONS DE COMMANDES
      // ═══════════════════════════════════════════════════════════
      
      await interaction.editReply('```ansi\n[2;33m╔════════════════════════════════════╗\n║   🎓 ACADÉMIE QUANTIQUE ACTIVE   ║\n╚════════════════════════════════════╝[0m\n```');
      
      const academyCategory = await guild.channels.create({
        name: '🎓・ACADÉMIE QUANTIQUE',
        type: ChannelType.GuildCategory,
      });
      
      const tutorialsChannel = await guild.channels.create({
        name: '📚・terminal-tutoriels',
        type: ChannelType.GuildText,
        parent: academyCategory.id,
        topic: '🎓 Utilise /tutoriels ici pour accéder aux cours',
      });
      
      const tutorialsEmbed = new EmbedBuilder()
        .setColor('#FFD700')
        .setTitle('```ansi\n[2;33m╔═══════════════════════════════════════════╗\n║     📚  TERMINAL DE TUTORIELS  📚       ║\n╚═══════════════════════════════════════════╝[0m\n```')
        .setDescription('```ansi\n[2;35m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀[0m\n```\n\n## 🎯 **ACCÈDE À L\'INTELLIGENCE COLLECTIVE**\n\n> Tape `/tutoriels` pour explorer notre bibliothèque quantique\n\n```ansi\n[2;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n[1;37m           PARCOURS DISPONIBLES            [0m\n[2;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n```\n\n### 🟢 **NIVEAU DÉBUTANT**\n└ Bases de la programmation\n└ Logique et algorithmes\n└ Premier projet\n\n### 🟡 **NIVEAU INTERMÉDIAIRE**\n└ Structures de données avancées\n└ POO et design patterns\n└ APIs et bases de données\n\n### 🔴 **NIVEAU AVANCÉ**\n└ Architecture logicielle\n└ Optimisation et performance\n└ Projets full-stack\n\n```ansi\n[2;33m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀[0m\n```')
        .setFooter({ text: '⚡ Mise à jour continue・Contenu premium gratuit' })
        .setTimestamp();
      
      await tutorialsChannel.send({ embeds: [tutorialsEmbed] });
      
      const projectsChannel = await guild.channels.create({
        name: '🚀・terminal-projets',
        type: ChannelType.GuildText,
        parent: academyCategory.id,
        topic: '💻 Utilise /projets ici pour voir les challenges',
      });
      
      const projectsEmbed = new EmbedBuilder()
        .setColor('#00E5FF')
        .setTitle('```ansi\n[2;36m╔═══════════════════════════════════════════╗\n║      🚀  TERMINAL DE PROJETS  🚀        ║\n╚═══════════════════════════════════════════╝[0m\n```')
        .setDescription('```ansi\n[2;35m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀[0m\n```\n\n## 💡 **TRANSFORME TES IDÉES EN RÉALITÉ**\n\n> Tape `/projets` pour découvrir nos challenges exclusifs\n\n```ansi\n[2;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n[1;37m          PROJETS PAR CATÉGORIE            [0m\n[2;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n```\n\n### 🎮 **GAMING**\n└ Snake Game\n└ Morpion IA\n└ RPG Text-Based\n\n### 🌐 **WEB APPS**\n└ Todo List avancée\n└ Portfolio interactif\n└ Chat en temps réel\n\n### 🤖 **AUTOMATION**\n└ Bot Discord\n└ Web Scraper\n└ Automatisation tâches\n\n### 📊 **DATA**\n└ Dashboard analytics\n└ Data visualization\n└ Machine Learning\n\n```ansi\n[2;36m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀[0m\n```')
        .setFooter({ text: '🏆 Complète des projets・Gagne des badges・Level up' })
        .setTimestamp();
      
      await projectsChannel.send({ embeds: [projectsEmbed] });
      
      const resourcesChannel = await guild.channels.create({
        name: '🔗・terminal-ressources',
        type: ChannelType.GuildText,
        parent: academyCategory.id,
        topic: '📖 Utilise /ressources ici pour les liens utiles',
      });
      
      // ═══════════════════════════════════════════════════════════
      // ÉTAPE 4: LABORATOIRES DE CODE
      // ═══════════════════════════════════════════════════════════
      
      await interaction.editReply('```ansi\n[2;32m╔════════════════════════════════════╗\n║   🧪 LABORATOIRES ACTIVÉS...     ║\n╚════════════════════════════════════╝[0m\n```');
      
      const labsCategory = await guild.channels.create({
        name: '🧪・LABORATOIRES',
        type: ChannelType.GuildCategory,
      });
      
      const labChannels = [
        { name: '🐍・python-lab', topic: '🐍 Laboratoire Python・Code & Debug', emoji: '🐍' },
        { name: '💛・javascript-lab', topic: '💛 Laboratoire JavaScript・Node & Web', emoji: '💛' },
        { name: '⚛️・react-lab', topic: '⚛️ Laboratoire React・Components & Hooks', emoji: '⚛️' },
        { name: '🎨・frontend-lab', topic: '🎨 Laboratoire Frontend・HTML CSS UI/UX', emoji: '🎨' },
        { name: '⚙️・backend-lab', topic: '⚙️ Laboratoire Backend・APIs & Servers', emoji: '⚙️' },
        { name: '🗄️・database-lab', topic: '🗄️ Laboratoire Databases・SQL & NoSQL', emoji: '🗄️' },
      ];
      
      for (const lab of labChannels) {
        const channel = await guild.channels.create({
          name: lab.name,
          type: ChannelType.GuildText,
          parent: labsCategory.id,
          topic: lab.topic,
        });
        
        const labEmbed = new EmbedBuilder()
          .setColor('#00FF41')
          .setDescription(`\`\`\`ansi\n[2;32m╔═══════════════════════════════╗\n║  ${lab.emoji} LABORATOIRE ACTIF ${lab.emoji}  ║\n╚═══════════════════════════════╝[0m\n\`\`\`\n\n**Zone de développement et d'expérimentation**\n\n✨ Partage ton code\n🐛 Debug ensemble\n💡 Pose tes questions\n🚀 Crée des projets`);
        
        await channel.send({ embeds: [labEmbed] });
        await new Promise(resolve => setTimeout(resolve, 300));
      }
      
      // ═══════════════════════════════════════════════════════════
      // ÉTAPE 5: ZONE SUPPORT FUTURISTE
      // ═══════════════════════════════════════════════════════════
      
      await interaction.editReply('```ansi\n[2;34m╔════════════════════════════════════╗\n║   🎫 SUPPORT QUANTIQUE ACTIF...  ║\n╚════════════════════════════════════╝[0m\n```');
      
      const supportCategory = await guild.channels.create({
        name: '🎫・SUPPORT QUANTIQUE',
        type: ChannelType.GuildCategory,
      });
      
      const supportChannel = await guild.channels.create({
        name: '🆘・terminal-support',
        type: ChannelType.GuildText,
        parent: supportCategory.id,
        topic: '🎫 Utilise /support ici pour créer un ticket privé',
      });
      
      const supportEmbed = new EmbedBuilder()
        .setColor('#B388FF')
        .setTitle('```ansi\n[2;35m╔═══════════════════════════════════════════╗\n║       🎫  SUPPORT QUANTIQUE  🎫         ║\n╚═══════════════════════════════════════════╝[0m\n```')
        .setDescription('```ansi\n[2;35m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀[0m\n```\n\n## 🆘 **ASSISTANCE IMMÉDIATE 24/7**\n\n> Tape `/support` pour créer un ticket privé avec un mentor\n\n```ansi\n[2;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n[1;37m          TYPES DE SUPPORT                 [0m\n[2;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n```\n\n### 🐛 **DEBUG**\n└ Erreurs de code\n└ Bugs mystérieux\n└ Stack traces\n\n### 💡 **CONSEILS**\n└ Architecture projet\n└ Best practices\n└ Optimisation\n\n### 🎓 **APPRENTISSAGE**\n└ Explications concepts\n└ Recommandations cours\n└ Mentorat personnalisé\n\n### ⚡ **URGENCE**\n└ Deadline proche\n└ Problème bloquant\n└ Aide express\n\n```ansi\n[2;35m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n[1;37m   ⏱️  TEMPS DE RÉPONSE: < 15 MIN  ⏱️     [0m\n[2;35m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n```')
        .setFooter({ text: '🎫 Support prioritaire・Mentors experts・Confidentialité garantie' })
        .setTimestamp();
      
      const supportButton = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('create_support_ticket')
            .setLabel('🎫 CRÉER UN TICKET')
            .setStyle(ButtonStyle.Danger)
        );
      
      await supportChannel.send({ embeds: [supportEmbed], components: [supportButton] });
      
      // ═══════════════════════════════════════════════════════════
      // ÉTAPE 6: ZONE SOCIALE & CHILL
      // ═══════════════════════════════════════════════════════════
      
      await interaction.editReply('```ansi\n[2;36m╔════════════════════════════════════╗\n║   🌟 ZONE SOCIALE ACTIVE...      ║\n╚════════════════════════════════════╝[0m\n```');
      
      const socialCategory = await guild.channels.create({
        name: '🌟・ZONE SOCIALE',
        type: ChannelType.GuildCategory,
      });
      
      const socialChannels = [
        { name: '💬・lounge-général', topic: '💬 Discussions libres entre codeurs' },
        { name: '🎮・gaming-zone', topic: '🎮 Gaming, détente, et fun!' },
        { name: '🎨・créations-visuelles', topic: '🎨 Partage tes créations graphiques' },
        { name: '🎵・musique-code', topic: '🎵 Ta playlist pour coder' },
        { name: '🍕・pause-café', topic: '☕ Zone chill et memes' },
        { name: '📸・screenshots', topic: '📸 Partage ton setup et projets' },
      ];
      
      for (const social of socialChannels) {
        await guild.channels.create({
          name: social.name,
          type: ChannelType.GuildText,
          parent: socialCategory.id,
          topic: social.topic,
        });
        await new Promise(resolve => setTimeout(resolve, 300));
      }
      
      // ═══════════════════════════════════════════════════════════
      // ÉTAPE 7: SHOWCASE & PORTFOLIOS
      // ═══════════════════════════════════════════════════════════
      
      const showcaseCategory = await guild.channels.create({
        name: '🏆・SHOWCASE',
        type: ChannelType.GuildCategory,
      });
      
      await guild.channels.create({
        name: '✨・projets-terminés',
        type: ChannelType.GuildText,
        parent: showcaseCategory.id,
        topic: '🏆 Montre tes projets finalisés!',
      });
      
      await guild.channels.create({
        name: '🚧・projets-en-cours',
        type: ChannelType.GuildText,
        parent: showcaseCategory.id,
        topic: '🚧 WIP - Partage ta progression',
      });
      
      await guild.channels.create({
        name: '💼・portfolios',
        type: ChannelType.GuildText,
        parent: showcaseCategory.id,
        topic: '💼 Partage ton portfolio professionnel',
      });
      
      await guild.channels.create({
        name: '🤝・collaborations',
        type: ChannelType.GuildText,
        parent: showcaseCategory.id,
        topic: '🤝 Trouve des collaborateurs',
      });
      
      // ═══════════════════════════════════════════════════════════
      // ÉTAPE 8: SALONS VOCAUX FUTURISTES
      // ═══════════════════════════════════════════════════════════
      
      const voiceCategory = await guild.channels.create({
        name: '🔊・DIMENSION VOCALE',
        type: ChannelType.GuildCategory,
      });
      
      const voiceChannels = [
        '🎙️・Hall Principal',
        '💻・Code Session #1',
        '💻・Code Session #2',
        '💻・Code Session #3',
        '🎓・Cours & Mentorat',
        '🤝・Pair Programming',
        '🎮・Gaming Lounge',
        '🎵・Music & Chill',
        '🔇・AFK Zone',
      ];
      
      for (const voiceName of voiceChannels) {
        await guild.channels.create({
          name: voiceName,
          type: ChannelType.GuildVoice,
          parent: voiceCategory.id,
        });
        await new Promise(resolve => setTimeout(resolve, 300));
      }
      
      // ═══════════════════════════════════════════════════════════
      // MESSAGE FINAL DE SUCCÈS
      // ═══════════════════════════════════════════════════════════
      
      const finalEmbed = new EmbedBuilder()
        .setColor('#00FF00')
        .setTitle('```ansi\n[2;32m╔═══════════════════════════════════════════════╗\n║                                               ║\n║    ✅  SERVEUR QUANTIQUE INITIALISÉ  ✅     ║\n║                                               ║\n╚═══════════════════════════════════════════════╝[0m\n```')
        .setDescription('```ansi\n[2;35m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀[0m\n```\n\n## 🌌 **BIENVENUE DANS LE FUTUR DU CODE**\n\n> Ton serveur est maintenant équipé de la technologie la plus avancée\n\n```ansi\n[2;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n[1;37m              STATISTIQUES SERVEUR              [0m\n[2;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n```\n\n### 📊 **INFRASTRUCTURE**\n\n🎨 **' + createdRoles.length + ' Rôles** créés avec système de rang\n📁 **8 Catégories** organisées parfaitement\n💬 **30+ Salons** texte optimisés\n🔊 **9 Salons** vocaux premium\n\n```ansi\n[2;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n```\n\n### 🚀 **FONCTIONNALITÉS ACTIVES**\n\n✅ Système de tutoriels quantiques\n✅ Projets avec tracking de progression\n✅ Support tickets ultra-rapide\n✅ Laboratoires par technologie\n✅ Zone sociale et détente\n✅ Showcase de projets\n✅ Système de rôles et progression\n\n```ansi\n[2;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n[1;37m            COMMANDES DISPONIBLES               [0m\n[2;36m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n```\n\n`/tutoriels` → Accès cours par niveau\n`/projets` → Challenges de code\n`/support` → Tickets privés\n`/ressources` → Liens utiles\n`/aide` → Guide complet\n\n```ansi\n[2;32m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀[0m\n```\n\n### 💎 **PROCHAINES ÉTAPES**\n\n1. Configure les permissions selon tes besoins\n2. Ajoute des emojis personnalisés au serveur\n3. Personnalise les messages de bienvenue\n4. Invite ta communauté!\n5. **COMMENCE À CODER! 🚀**\n\n```ansi\n[2;35m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n[1;37m        🌟 SERVEUR PAR FAC BOT v2.0 🌟         [0m\n[2;35m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m\n```')
        .setFooter({ text: '⚡ Système Quantique・Technologie Futuriste・Design Unique' })
        .setTimestamp();
      
      await interaction.editReply({ embeds: [finalEmbed] });
      
    } catch (error) {
      console.error('Erreur setup:', error);
      await interaction.editReply({
        content: '```ansi\n[2;31m╔════════════════════════════════════╗\n║      ❌ ERREUR QUANTIQUE ❌       ║\n╚════════════════════════════════════╝[0m\n```\n\n**Erreur:** ' + error.message + '\n\n**Solution:** Vérifie les permissions du bot (Gérer les rôles, Gérer les salons)',
      });
    }
  },
};
