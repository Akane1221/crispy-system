
const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pub')
    .setDescription('📢 Envoie un message promotionnel à tous les membres de tous les serveurs')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    
    const client = interaction.client;
    const inviteLink = 'https://discord.gg/T6XEhxuP';
    
    let totalMembers = 0;
    let successfulDMs = 0;
    let failedDMs = 0;
    
    const statusEmbed = new EmbedBuilder()
      .setColor('#FFA500')
      .setTitle('```ansi\n\u001b[2;33m╔═══════════════════════════════════════════╗\n║     📤  ENVOI EN COURS...  📤           ║\n╚═══════════════════════════════════════════╝\u001b[0m\n```')
      .setDescription('⏳ Préparation de l\'envoi...')
      .setTimestamp();
    
    await interaction.editReply({ embeds: [statusEmbed] });
    
    for (const [guildId, guild] of client.guilds.cache) {
      try {
        const members = await guild.members.fetch();
        
        for (const [memberId, member] of members) {
          if (member.user.bot) continue;
          
          totalMembers++;
          
          const dmEmbed = new EmbedBuilder()
            .setColor('#00D9FF')
            .setTitle('```ansi\n\u001b[2;36m╔═══════════════════════════════════════════════════════╗\n║     🚀  FAC - FORMATION AVANCÉE EN CODAGE  🚀        ║\n╚═══════════════════════════════════════════════════════╝\u001b[0m\n```')
            .setDescription(`
**Salut ${member.user.username}** 👋

Tu reçois ce message car tu fais partie d'un serveur où **FAC Bot** est présent !

\`\`\`ansi
\u001b[2;35m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀\u001b[0m
\u001b[2;33m          🎓 REJOINS NOTRE COMMUNAUTÉ DE CODEURS !     \u001b[0m
\u001b[2;35m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀\u001b[0m
\`\`\`

### 💎 **CE QU'ON T'OFFRE**

\`\`\`diff
+ 🎓 Tutoriels gratuits de A à Z
+ 💻 Projets concrets pour ton portfolio
+ 🤖 Bot interactif avec commandes utiles
+ 👥 Communauté active 24/7
+ 🏆 Défis de code et événements
+ 📚 Ressources premium gratuites
+ 🎫 Support technique instantané
+ ⭐ Mentorat par des experts
\`\`\`

\`\`\`ansi
\u001b[2;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\u001b[0m
\`\`\`

### 🌟 **LANGAGES & TECHNOLOGIES**

\`\`\`yaml
JavaScript • Python • Java • C++ • C# • PHP
TypeScript • Go • Rust • HTML/CSS • SQL
React • Vue • Angular • Node.js • Django
\`\`\`

\`\`\`ansi
\u001b[2;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\u001b[0m
\`\`\`

### 🎯 **POURQUOI FAC ?**

> ✨ **100% Gratuit** - Aucun frais caché
> 🚀 **Débutant ou expert** - Tous les niveaux
> 💡 **Apprentissage pratique** - Projets réels
> 🏅 **Certificats** - Valorise tes compétences
> 🤝 **Entraide** - Jamais seul face aux bugs

\`\`\`ansi
\u001b[2;34m▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰\u001b[0m
\`\`\`
            `)
            .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 256 }))
            .setImage('https://media.discordapp.net/attachments/placeholder/banner.png')
            .setFooter({ text: '🔥 Rejoins-nous et transforme ta passion en compétence!' })
            .setTimestamp();

          const inviteEmbed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('```ansi\n\u001b[2;32m╔═══════════════════════════════════════════════════════╗\n║          🎊  CLIQUE ICI POUR REJOINDRE  🎊          ║\n╚═══════════════════════════════════════════════════════╝\u001b[0m\n```')
            .setDescription(`
### 🔗 **LIEN D'INVITATION**

**👉 ${inviteLink} 👈**

\`\`\`ansi
\u001b[2;36m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀\u001b[0m
\u001b[2;37m  ⚡  +500 développeurs actifs chaque jour             \u001b[0m
\u001b[2;37m  🎯  100+ tutoriels et projets disponibles            \u001b[0m
\u001b[2;37m  💬  Support réactif en moins de 15 minutes           \u001b[0m
\u001b[2;36m▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀\u001b[0m
\`\`\`

### 🎁 **BONUS NOUVEAUX MEMBRES**

🌟 Rôle **"Nouveau Codeur"** exclusif
📖 **Guide de démarrage** personnalisé  
🎯 **Accès immédiat** à tous les tutoriels
🤝 **Parrain personnel** pour t'accompagner

\`\`\`ansi
\u001b[2;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\u001b[0m
\`\`\`

### 💬 **TÉMOIGNAGES**

> *"J'ai trouvé mon premier job grâce à FAC !"* - Alexandre

> *"La meilleure communauté francophone de devs"* - Marie

> *"Support ultra-réactif, top niveau !"* - Thomas

\`\`\`ansi
\u001b[2;32m▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰\u001b[0m
\u001b[2;37m         🚀 ON T'ATTEND SUR FAC ! 🚀                   \u001b[0m
\u001b[2;32m▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰\u001b[0m
\`\`\`
            `)
            .setFooter({ text: '💎 FAC - Où les passionnés deviennent des experts • discord.gg/T6XEhxuP' })
            .setTimestamp();

          try {
            await member.send({ embeds: [dmEmbed, inviteEmbed] });
            successfulDMs++;
            
            if (successfulDMs % 10 === 0) {
              const progressEmbed = new EmbedBuilder()
                .setColor('#FFA500')
                .setTitle('```ansi\n\u001b[2;33m╔═══════════════════════════════════════════╗\n║     📤  ENVOI EN COURS...  📤           ║\n╚═══════════════════════════════════════════╝\u001b[0m\n```')
                .setDescription(`📊 **Progression**\n\n✅ Envoyés: ${successfulDMs}\n❌ Échecs: ${failedDMs}\n📋 Total traité: ${totalMembers}\n\n⏳ En cours...`)
                .setTimestamp();
              
              await interaction.editReply({ embeds: [progressEmbed] });
            }
            
            await new Promise(resolve => setTimeout(resolve, 1000));
            
          } catch (error) {
            failedDMs++;
          }
        }
      } catch (error) {
        console.error(`Erreur pour le serveur ${guild.name}:`, error);
      }
    }
    
    const finalEmbed = new EmbedBuilder()
      .setColor('#00FF00')
      .setTitle('```ansi\n\u001b[2;32m╔═══════════════════════════════════════════╗\n║     ✅  ENVOI TERMINÉ !  ✅             ║\n╚═══════════════════════════════════════════╝\u001b[0m\n```')
      .setDescription(`
### 📊 **RÉSULTATS DE L'ENVOI**

\`\`\`ansi
\u001b[2;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\u001b[0m
\`\`\`

✅ **Messages envoyés:** ${successfulDMs}
❌ **Échecs:** ${failedDMs}
📋 **Total de membres:** ${totalMembers}
🌐 **Serveurs:** ${client.guilds.cache.size}

\`\`\`ansi
\u001b[2;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\u001b[0m
\`\`\`

${failedDMs > 0 ? '⚠️ *Certains utilisateurs ont leurs DMs désactivés*' : '🎉 *Tous les messages ont été envoyés avec succès !*'}

**📈 Taux de réussite:** ${totalMembers > 0 ? Math.round((successfulDMs / totalMembers) * 100) : 0}%
      `)
      .setFooter({ text: '💎 Campagne de publicité FAC Bot' })
      .setTimestamp();
    
    await interaction.editReply({ embeds: [finalEmbed] });
  },
};
