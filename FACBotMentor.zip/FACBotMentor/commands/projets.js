
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const projectsData = require('../data/projects.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('projets')
    .setDescription('🚀 Catalogue de projets premium pour devenir un dev d\'élite'),
  
  async execute(interaction) {
    const mainEmbed = new EmbedBuilder()
      .setColor('#00D4FF')
      .setTitle('⚡ PROJECT HUB ⚡')
      .setDescription('```ansi\n[2;36m╔════════════════════════════════════════╗\n║  [1;37mCATALOGUE EXCLUSIF DE PROJETS PRO[0m  [2;36m║\n╚════════════════════════════════════════╝[0m\n```\n\n> *Transforme ton apprentissage en portfolio concret*\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n### 📊 **STATS EN TEMPS RÉEL**\n\n```yaml\n🟢 Projets Débutant:     ' + projectsData.projects.filter(p => p.difficulty === 'Débutant').length + ' disponibles\n🟡 Projets Intermédiaire: ' + projectsData.projects.filter(p => p.difficulty === 'Intermédiaire').length + ' disponibles\n🔴 Projets Avancé:        ' + projectsData.projects.filter(p => p.difficulty === 'Avancé').length + ' disponibles\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n📦 Total:                 ' + projectsData.projects.length + ' projets premium\n```\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n### 🎯 **POURQUOI CES PROJETS?**\n\n✦ **Portfolio** - Impressionne les recruteurs\n✦ **Compétences** - Pratique = Maîtrise\n✦ **Challenges** - Repousse tes limites\n✦ **Open Source** - Contribue à la communauté\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n### 💎 **BONUS EXCLUSIFS**\n\n🎁 Code starter fourni pour chaque projet\n📚 Ressources et tutoriels inclus\n🏆 Système de badges de complétion\n👥 Support communautaire actif\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
      .setThumbnail('https://cdn.discordapp.com/attachments/placeholder-rocket.gif')
      .setFooter({ 
        text: '『 FAC PROJECT HUB 』• Elite Developer Program • V4.0',
        iconURL: interaction.client.user.displayAvatarURL()
      })
      .setTimestamp();

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('project_select')
      .setPlaceholder('⚡ Sélectionne un projet qui te challenge')
      .addOptions(
        projectsData.projects.map(project => {
          let emoji = '🟢';
          if (project.difficulty === 'Intermédiaire') emoji = '🟡';
          if (project.difficulty === 'Avancé') emoji = '🔴';
          
          return {
            label: project.title.replace(/[^\w\s-]/g, ''),
            description: `${project.difficulty} • ${project.estimated_time}`,
            value: project.id,
            emoji: emoji
          };
        })
      );

    const buttonRow = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('filter_beginner')
          .setLabel('Débutant')
          .setEmoji('🟢')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('filter_intermediate')
          .setLabel('Intermédiaire')
          .setEmoji('🟡')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('filter_advanced')
          .setLabel('Avancé')
          .setEmoji('🔴')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setLabel('Guide Projets')
          .setEmoji('📖')
          .setStyle(ButtonStyle.Link)
          .setURL('https://replit.com/@your-username')
      );

    const row = new ActionRowBuilder().addComponents(selectMenu);

    await interaction.reply({
      embeds: [mainEmbed],
      components: [row, buttonRow]
    });
  },
};
