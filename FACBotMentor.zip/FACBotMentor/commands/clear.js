
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('🧹 Supprime TOUS les salons et rôles (DANGEREUX)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor('#FF1744')
      .setTitle('⚠️ ALERTE CRITIQUE')
      .setDescription('```ansi\n[2;31m╔═══════════════════════════════════════╗\n║    ⚠️  ZONE DANGEREUSE DÉTECTÉE  ⚠️    ║\n╚═══════════════════════════════════════╝[0m\n```\n\n**🔥 CETTE ACTION VA:**\n\n```diff\n- Supprimer TOUS les salons\n- Supprimer TOUS les rôles\n- Effacer toute la configuration\n- Réinitialiser le serveur\n```\n\n**⚠️ IMPOSSIBLE À ANNULER**\n\nEs-tu ABSOLUMENT certain de vouloir continuer?\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
      .setFooter({ text: '⚠️ Cette action est irréversible' })
      .setTimestamp();

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('confirm_server_clear')
          .setLabel('OUI, TOUT SUPPRIMER')
          .setEmoji('💀')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('cancel_server_clear')
          .setLabel('Annuler')
          .setEmoji('✅')
          .setStyle(ButtonStyle.Secondary)
      );

    await interaction.reply({
      embeds: [embed],
      components: [row],
      ephemeral: true
    });
  },
};
