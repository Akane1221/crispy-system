const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('server')
    .setDescription('🏗️ Crée une structure de serveur complète pour FAC Bot')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    
    const guild = interaction.guild;
    
    try {
      await interaction.editReply('🚀 Création du serveur en cours... Cela peut prendre quelques minutes!');
      
      const createdChannels = [];
      const createdRoles = [];
      
      await interaction.editReply('🎨 Étape 1/6: Création des rôles...');
      
      const roles = [
        { name: '👑 Admin', color: '#e74c3c', permissions: [PermissionFlagsBits.Administrator] },
        { name: '🛡️ Modérateur', color: '#e67e22', permissions: [PermissionFlagsBits.ModerateMembers, PermissionFlagsBits.ManageMessages, PermissionFlagsBits.KickMembers] },
        { name: '🎓 Mentor', color: '#3498db', permissions: [PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks] },
        { name: '⭐ Expert', color: '#f39c12', permissions: [] },
        { name: '🟡 Avancé', color: '#9b59b6', permissions: [] },
        { name: '🟢 Intermédiaire', color: '#2ecc71', permissions: [] },
        { name: '🔵 Débutant', color: '#1abc9c', permissions: [] },
        { name: '🤖 Bot', color: '#95a5a6', permissions: [] },
      ];
      
      for (const roleData of roles) {
        try {
          const role = await guild.roles.create({
            name: roleData.name,
            color: roleData.color,
            permissions: roleData.permissions,
            mentionable: true
          });
          createdRoles.push(role);
          await new Promise(resolve => setTimeout(resolve, 500));
        } catch (err) {
          console.error(`Erreur création rôle ${roleData.name}:`, err);
        }
      }
      
      await interaction.editReply('📋 Étape 2/6: Création de la catégorie INFORMATIONS...');
      
      const infoCategory = await guild.channels.create({
        name: '📋 INFORMATIONS',
        type: ChannelType.GuildCategory
      });
      
      const infoChannels = [
        { name: '📢・annonces', topic: 'Toutes les annonces importantes du serveur' },
        { name: '📜・règles', topic: 'Les règles du serveur à respecter' },
        { name: '👋・bienvenue', topic: 'Bienvenue aux nouveaux membres!' },
        { name: '🎯・objectifs', topic: 'Les objectifs d\'apprentissage de la communauté' },
        { name: '📊・statistiques', topic: 'Statistiques du serveur et de la communauté' }
      ];
      
      for (const channelData of infoChannels) {
        const channel = await guild.channels.create({
          name: channelData.name,
          type: ChannelType.GuildText,
          parent: infoCategory.id,
          topic: channelData.topic,
          permissionOverwrites: [
            {
              id: guild.id,
              deny: [PermissionFlagsBits.SendMessages]
            }
          ]
        });
        createdChannels.push(channel);
        await new Promise(resolve => setTimeout(resolve, 300));
      }
      
      await interaction.editReply('💻 Étape 3/6: Création de la catégorie APPRENTISSAGE...');
      
      const learningCategory = await guild.channels.create({
        name: '💻 APPRENTISSAGE',
        type: ChannelType.GuildCategory
      });
      
      const learningChannels = [
        { name: '💬・général', topic: 'Discussions générales sur le code' },
        { name: '🐍・python', topic: 'Tout sur Python' },
        { name: '💛・javascript', topic: 'JavaScript et Node.js' },
        { name: '🎨・html-css', topic: 'Design web avec HTML et CSS' },
        { name: '⚛️・react', topic: 'React et frameworks modernes' },
        { name: '🗄️・bases-de-données', topic: 'SQL, MongoDB, et plus' },
        { name: '🔧・git-github', topic: 'Versioning et collaboration' },
        { name: '📱・mobile', topic: 'Développement mobile' }
      ];
      
      for (const channelData of learningChannels) {
        const channel = await guild.channels.create({
          name: channelData.name,
          type: ChannelType.GuildText,
          parent: learningCategory.id,
          topic: channelData.topic
        });
        createdChannels.push(channel);
        await new Promise(resolve => setTimeout(resolve, 300));
      }
      
      await interaction.editReply('🚀 Étape 4/6: Création de la catégorie PROJETS...');
      
      const projectsCategory = await guild.channels.create({
        name: '🚀 PROJETS & PORTFOLIOS',
        type: ChannelType.GuildCategory
      });
      
      const projectChannels = [
        { name: '💡・idées-projets', topic: 'Partage tes idées de projets' },
        { name: '🎯・projets-en-cours', topic: 'Montre tes projets en développement' },
        { name: '✨・projets-terminés', topic: 'Partage tes créations finalisées' },
        { name: '🤝・collaborations', topic: 'Trouve des partenaires pour coder ensemble' },
        { name: '👨‍💻・code-review', topic: 'Demande des avis sur ton code' },
        { name: '🏆・challenges', topic: 'Défis de code hebdomadaires' }
      ];
      
      for (const channelData of projectChannels) {
        const channel = await guild.channels.create({
          name: channelData.name,
          type: ChannelType.GuildText,
          parent: projectsCategory.id,
          topic: channelData.topic
        });
        createdChannels.push(channel);
        await new Promise(resolve => setTimeout(resolve, 300));
      }
      
      await interaction.editReply('🎫 Étape 5/6: Création de la catégorie SUPPORT...');
      
      const supportCategory = await guild.channels.create({
        name: '🎫 SUPPORT',
        type: ChannelType.GuildCategory
      });
      
      const supportChannels = [
        { name: '❓・questions', topic: 'Pose tes questions ici' },
        { name: '🐛・bugs-erreurs', topic: 'Aide pour débugger ton code' },
        { name: '🆘・aide-urgente', topic: 'Besoin d\'aide rapidement?' },
        { name: '💬・mentorat', topic: 'Trouve un mentor ou deviens mentor' }
      ];
      
      for (const channelData of supportChannels) {
        const channel = await guild.channels.create({
          name: channelData.name,
          type: ChannelType.GuildText,
          parent: supportCategory.id,
          topic: channelData.topic
        });
        createdChannels.push(channel);
        await new Promise(resolve => setTimeout(resolve, 300));
      }
      
      await interaction.editReply('🎉 Étape 6/6: Création des catégories COMMUNAUTÉ et VOCAL...');
      
      const communityCategory = await guild.channels.create({
        name: '🌟 COMMUNAUTÉ',
        type: ChannelType.GuildCategory
      });
      
      const communityChannels = [
        { name: '💭・discussions', topic: 'Discussions libres entre membres' },
        { name: '🎮・hors-sujet', topic: 'Détends-toi et parle d\'autre chose' },
        { name: '📰・ressources', topic: 'Partage des liens et ressources utiles' },
        { name: '🎤・événements', topic: 'Événements et sessions de code en live' },
        { name: '🎨・créations', topic: 'Partage tes créations artistiques' },
        { name: '🤖・bot-commandes', topic: 'Teste les commandes du bot ici' }
      ];
      
      for (const channelData of communityChannels) {
        const channel = await guild.channels.create({
          name: channelData.name,
          type: ChannelType.GuildText,
          parent: communityCategory.id,
          topic: channelData.topic
        });
        createdChannels.push(channel);
        await new Promise(resolve => setTimeout(resolve, 300));
      }
      
      const voiceCategory = await guild.channels.create({
        name: '🔊 SALONS VOCAUX',
        type: ChannelType.GuildCategory
      });
      
      const voiceChannels = [
        '🎙️ Hall Principal',
        '💻 Code Session #1',
        '💻 Code Session #2',
        '🎓 Cours & Mentorat',
        '🤝 Pair Programming',
        '🎮 Détente & Gaming',
        '🔇 AFK'
      ];
      
      for (const voiceName of voiceChannels) {
        const channel = await guild.channels.create({
          name: voiceName,
          type: ChannelType.GuildVoice,
          parent: voiceCategory.id
        });
        createdChannels.push(channel);
        await new Promise(resolve => setTimeout(resolve, 300));
      }
      
      const welcomeChannel = createdChannels.find(c => c.name === '👋・bienvenue');
      if (welcomeChannel) {
        const welcomeEmbed = new EmbedBuilder()
          .setColor('#2ecc71')
          .setTitle('🎉 Bienvenue sur le Serveur FAC Bot!')
          .setDescription('Bienvenue dans notre communauté d\'apprentissage du code!\n\n**Ce serveur a été créé pour:**\n✅ Apprendre à coder ensemble\n✅ S\'entraider et progresser\n✅ Partager des projets et des idées\n✅ Créer une communauté solidaire')
          .addFields(
            { name: '📚 Commence par:', value: 'Utilise `/tutoriels` pour explorer les cours disponibles', inline: false },
            { name: '🚀 Ensuite:', value: 'Choisis ton niveau avec les rôles 🔵 Débutant, 🟢 Intermédiaire, ou 🟡 Avancé', inline: false },
            { name: '💡 Besoin d\'aide?', value: 'Va dans #questions ou crée un ticket avec `/support`', inline: false },
            { name: '🎯 Objectif:', value: 'Progresser ensemble et créer des projets incroyables!', inline: false }
          )
          .setFooter({ text: 'FAC Bot - Apprends, Code, Crée!' })
          .setTimestamp();
        
        await welcomeChannel.send({ embeds: [welcomeEmbed] });
      }
      
      const rulesChannel = createdChannels.find(c => c.name === '📜・règles');
      if (rulesChannel) {
        const rulesEmbed = new EmbedBuilder()
          .setColor('#e74c3c')
          .setTitle('📜 Règles du Serveur')
          .setDescription('**Pour que notre communauté reste agréable et productive:**\n')
          .addFields(
            { name: '1️⃣ Respect', value: 'Sois respectueux envers tous les membres, peu importe leur niveau', inline: false },
            { name: '2️⃣ Entraide', value: 'N\'hésite pas à aider les autres et à demander de l\'aide', inline: false },
            { name: '3️⃣ Spam', value: 'Évite le spam et utilise les salons appropriés', inline: false },
            { name: '4️⃣ Code', value: 'Utilise les blocs de code pour partager ton code (\\`\\`\\`)', inline: false },
            { name: '5️⃣ Plagiat', value: 'Ne copie pas le code des autres sans comprendre', inline: false },
            { name: '6️⃣ Hors-sujet', value: 'Utilise #hors-sujet pour les discussions non liées au code', inline: false },
            { name: '⚠️ Sanctions', value: 'Le non-respect des règles peut entraîner des sanctions', inline: false }
          )
          .setFooter({ text: 'Merci de respecter ces règles!' })
          .setTimestamp();
        
        await rulesChannel.send({ embeds: [rulesEmbed] });
      }
      
      const botCommandsChannel = createdChannels.find(c => c.name === '🤖・bot-commandes');
      if (botCommandsChannel) {
        const botEmbed = new EmbedBuilder()
          .setColor('#3498db')
          .setTitle('🤖 Commandes FAC Bot')
          .setDescription('Voici toutes les commandes disponibles:\n')
          .addFields(
            { name: '/tutoriels', value: '📚 Explore les tutoriels par niveau et langage', inline: true },
            { name: '/projets', value: '🚀 Découvre des projets pratiques à réaliser', inline: true },
            { name: '/aide', value: '❓ Affiche l\'aide complète', inline: true },
            { name: '/ressources', value: '🔗 Liens vers ressources d\'apprentissage', inline: true },
            { name: '/support', value: '🎫 Crée un ticket de support privé', inline: true },
            { name: '/server', value: '🏗️ Crée la structure du serveur (Admin)', inline: true }
          )
          .setFooter({ text: 'Tape / pour voir toutes les commandes!' })
          .setTimestamp();
        
        await botCommandsChannel.send({ embeds: [botEmbed] });
      }
      
      const finalEmbed = new EmbedBuilder()
        .setColor('#2ecc71')
        .setTitle('✅ Serveur Créé avec Succès!')
        .setDescription('Le serveur FAC Bot a été configuré avec une structure complète!\n\n**⚠️ Note:** Cette commande peut être exécutée une seule fois. La relancer créera des doublons.')
        .addFields(
          { name: '🎨 Rôles créés', value: `${createdRoles.length} rôles`, inline: true },
          { name: '📝 Salons créés', value: `${createdChannels.length} salons`, inline: true },
          { name: '📋 Catégories', value: '6 catégories', inline: true },
          { name: '📚 Catégories créées', value: '• 📋 Informations\n• 💻 Apprentissage\n• 🚀 Projets & Portfolios\n• 🎫 Support\n• 🌟 Communauté\n• 🔊 Salons Vocaux', inline: false },
          { name: '💡 Prochaines étapes', value: '1. Configure les permissions selon tes besoins\n2. Personnalise les messages de bienvenue\n3. Invite les membres!\n4. Utilise `/tutoriels` pour commencer', inline: false }
        )
        .setFooter({ text: 'Serveur configuré par FAC Bot' })
        .setTimestamp();
      
      await interaction.editReply({ embeds: [finalEmbed] });
      
    } catch (error) {
      console.error('Erreur lors de la création du serveur:', error);
      await interaction.editReply({
        content: `❌ Une erreur est survenue lors de la création du serveur.\n\n**Erreur:** ${error.message}\n\n**Conseil:** Assure-toi que le bot a les permissions nécessaires (Gérer les rôles, Gérer les salons, Gérer les permissions).`
      });
    }
  },
};
